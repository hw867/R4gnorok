#!/usr/bin/env python3
# 在 Ubuntu 上运行此脚本，生成正确的 api.c 文件
# 用法：python3 generate_api_c.py

content = r"""#include "api.h"
#include "auth.h"
#include "favorite.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <microhttpd.h>

// ========= 全局配置 =========
static const char *G_SERVER_BASE_URL = "http://192.168.1.114:8080";

// ========= 响应辅助函数 =========

int api_send_json(struct MHD_Connection *connection,
                 int status_code,
                 const char *json_body) {
    if (!connection || !json_body) return MHD_NO;

    struct MHD_Response *response = MHD_create_response_from_buffer(
        strlen(json_body),
        (void*)json_body,
        MHD_RESPMEM_MUST_COPY
    );

    if (!response) return MHD_NO;

    MHD_add_response_header(response, "Content-Type", "application/json; charset=utf-8");
    MHD_add_response_header(response, "Access-Control-Allow-Origin", "*");

    int ret = MHD_queue_response(connection, status_code, response);
    MHD_destroy_response(response);
    return ret;
}

// ========= 文件读取回调 =========

static ssize_t file_reader_callback(void *cls,
                                    uint64_t pos,
                                    char *buf,
                                    size_t max) {
    FILE *fp = (FILE*)cls;
    if (!fp) return MHD_CONTENT_READER_END_WITH_ERROR;
    fseek(fp, (long)pos, SEEK_SET);
    size_t read_bytes = fread(buf, 1, max, fp);
    if (read_bytes == 0 && ferror(fp)) return MHD_CONTENT_READER_END_WITH_ERROR;
    if (read_bytes == 0) return MHD_CONTENT_READER_END_OF_STREAM;
    return (ssize_t)read_bytes;
}

static void file_free_callback(void *cls) {
    FILE *fp = (FILE*)cls;
    if (fp) fclose(fp);
}

int api_send_file(struct MHD_Connection *connection,
                  const char *file_path) {
    if (!connection || !file_path) return MHD_NO;

    FILE *fp = fopen(file_path, "rb");
    if (!fp) {
        const char *not_found = "404 Not Found";
        struct MHD_Response *response = MHD_create_response_from_buffer(
            strlen(not_found), (void*)not_found, MHD_RESPMEM_PERSISTENT);
        if (response) {
            MHD_add_response_header(response, "Content-Type", "text/plain");
            int ret = MHD_queue_response(connection, 404, response);
            MHD_destroy_response(response);
            return ret;
        }
        return MHD_NO;
    }

    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    struct MHD_Response *response = MHD_create_response_from_callback(
        (uint64_t)file_size,
        1024,
        &file_reader_callback,
        fp,
        &file_free_callback
    );

    if (!response) {
        fclose(fp);
        return MHD_NO;
    }

    const char *content_type = "text/html; charset=utf-8";
    if (strstr(file_path, ".css")) content_type = "text/css";
    else if (strstr(file_path, ".js")) content_type = "application/javascript";
    else if (strstr(file_path, ".png")) content_type = "image/png";
    else if (strstr(file_path, ".jpg") || strstr(file_path, ".jpeg")) content_type = "image/jpeg";

    MHD_add_response_header(response, "Content-Type", content_type);

    int ret = MHD_queue_response(connection, 200, response);
    MHD_destroy_response(response);
    return ret;
}

// ========= 发送二维码确认页面 =========

static int send_qr_html(struct MHD_Connection *connection, const char *token) {
    if (!token) return MHD_NO;

    char html[8192];
    int len = snprintf(html, sizeof(html),
        "<!DOCTYPE html>"
        "<html><head>"
        "<meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        "<title>扫码登录确认</title>"
        "<style>"
        "body{font-family:sans-serif;text-align:center;padding:20px;background:#f5f5f5;margin:0;}"
        ".container{background:white;max-width:380px;margin:40px auto;padding:30px 25px;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.1);}"
        "h2{color:#333;margin-bottom:8px;}"
        "p{color:#666;font-size:14px;margin-bottom:20px;}"
        ".form-group{text-align:left;margin-bottom:16px;}"
        ".form-group label{display:block;color:#333;font-size:14px;margin-bottom:6px;font-weight:bold;}"
        ".form-group input{width:100%%;padding:10px 12px;border:1px solid #ddd;border-radius:6px;font-size:15px;box-sizing:border-box;}"
        ".form-group input:focus{outline:none;border-color:#1DB954;}"
        ".btn-confirm{width:100%%;padding:12px;font-size:16px;border:none;border-radius:6px;cursor:pointer;background:#1DB954;color:white;margin-top:8px;}"
        ".btn-confirm:active{background:#169c46;}"
        ".btn-cancel{width:100%%;padding:10px;font-size:14px;border:1px solid #ddd;background:white;color:#666;border-radius:6px;cursor:pointer;margin-top:12px;}"
        ".msg{margin-top:12px;font-size:13px;}"
        ".msg.success{color:green;}"
        ".msg.error{color:red;}"
        "</style>"
        "</head><body>"
        "<div class=\"container\">"
        "<h2>🎵 音乐播放器登录确认</h2>"
        "<p>请确认登录此设备</p>"
        "<form id=\"loginForm\" onsubmit=\"doConfirm(event)\">"
        "<div class=\"form-group\">"
        "<label>用户名</label>"
        "<input type=\"text\" id=\"username\" placeholder=\"请输入用户名\" required autocomplete=\"username\">"
        "</div>"
        "<div class=\"form-group\">"
        "<label>密码</label>"
        "<input type=\"password\" id=\"password\" placeholder=\"请输入密码\" required autocomplete=\"current-password\">"
        "</div>"
        "<button type=\"submit\" class=\"btn-confirm\">确认登录</button>"
        "</form>"
        "<button class=\"btn-cancel\" onclick=\"cancelLogin()\">取消</button>"
        "<div class=\"msg\" id=\"msg\"></div>"
        "</div>"
        "<script>"
        "function doConfirm(e){"
        "  e.preventDefault();"
        "  var u=document.getElementById('username').value.trim();"
        "  var p=document.getElementById('password').value;"
        "  var msg=document.getElementById('msg');"
        "  if(!u||!p){msg.className='msg error';msg.innerText='请输入用户名和密码';return;}"
        "  msg.innerText='正在确认...';"
        "  msg.className='msg';"
        "  var xhr=new XMLHttpRequest();"
        "  xhr.open('POST','/api/login/confirm',true);"
        "  xhr.setRequestHeader('Content-Type','application/json');"
        "  xhr.onload=function(){"
        "    var res;"
        "    try{res=JSON.parse(xhr.responseText);}catch(e){msg.className='msg error';msg.innerText='服务器响应异常';return;}"
        "    if(res.code==0){"
        "      msg.className='msg success';"
        "      msg.innerText='登录成功！请在客户端查看';"
        "      document.getElementById('loginForm').style.display='none';"
        "    }else{"
        "      msg.className='msg error';"
        "      msg.innerText=res.message||'确认失败';"
        "    }"
        "  };"
        "  xhr.onerror=function(){msg.className='msg error';msg.innerText='网络错误，请重试';};"
        "  xhr.send(JSON.stringify({token:'%s',username:u,password:p}));"
        "}"
        "function cancelLogin(){"
        "  document.getElementById('msg').className='msg';"
        "  document.getElementById('msg').innerText='已取消登录';"
        "  setTimeout(function(){window.close();},1000);"
        "}"
        "</script>"
        "</body></html>",
        token
    );

    if (len <= 0) return MHD_NO;

    struct MHD_Response *response = MHD_create_response_from_buffer(
        (size_t)len, html, MHD_RESPMEM_MUST_COPY);

    if (!response) return MHD_NO;

    MHD_add_response_header(response, "Content-Type", "text/html; charset=utf-8");

    int ret = MHD_queue_response(connection, 200, response);
    MHD_destroy_response(response);
    return ret;
}

// ========= URL路由解析 =========

static int parse_qr_token(const char *url, char *token_buf, size_t buf_size) {
    if (!url || !token_buf) return -1;
    if (strncmp(url, "/qr/", 4) != 0) return -1;

    const char *token_start = url + 4;
    const char *token_end = token_start;
    while (*token_end && *token_end != '?') token_end++;

    size_t len = token_end - token_start;
    if (len == 0 || len >= buf_size) return -1;

    strncpy(token_buf, token_start, len);
    token_buf[len] = '\0';
    return 0;
}

static char* get_query_value(const char *query_string, const char *key) {
    if (!query_string || !key) return NULL;

    char *qs = strdup(query_string);
    if (!qs) return NULL;

    char *result = NULL;
    char *saveptr = NULL;
    char *token = strtok_r(qs, "&", &saveptr);

    while (token) {
        char *eq = strchr(token, '=');
        if (eq) {
            *eq = '\0';
            if (strcmp(token, key) == 0) {
                result = strdup(eq + 1);
                break;
            }
        }
        token = strtok_r(NULL, "&", &saveptr);
    }

    free(qs);
    return result;
}

// ========= POST数据读取 =========

struct PostData {
    char *body;
    size_t body_size;
    size_t body_capacity;
};

// ========= 核心请求处理 =========
// 正确的POST数据处理方式：
// 1. 第一次调用：初始化 PostData，存入 con_cls，返回 MHD_YES
// 2. upload_data_size > 0：把 upload_data 追加到 body，
//    把 *upload_data_size 置零（表示数据已消费），返回 MHD_YES
// 3. upload_data_size == 0：所有数据已接收，处理请求并回复

int api_handler(void *cls,
               struct MHD_Connection *connection,
               const char *url,
               const char *method,
               const char *version,
               const char *upload_data,
               size_t *upload_data_size,
               void **con_cls) {

    (void)cls; (void)version;

    // ========= 第一次调用：初始化 =========
    if (*con_cls == NULL) {
        struct PostData *pd = (struct PostData*)calloc(1, sizeof(struct PostData));
        if (!pd) return MHD_NO;
        pd->body_capacity = 4096;
        pd->body = (char*)malloc(pd->body_capacity);
        if (!pd->body) {
            free(pd);
            return MHD_NO;
        }
        pd->body[0] = '\0';
        pd->body_size = 0;
        *con_cls = pd;
        return MHD_YES;
    }

    struct PostData *pd = (struct PostData*)*con_cls;

    // ========= POST 请求 =========
    if (strcmp(method, "POST") == 0) {
        // 还有数据需要读取
        if (*upload_data_size > 0) {
            // 扩容（如果需要）
            size_t needed = pd->body_size + *upload_data_size + 1;
            if (needed > pd->body_capacity) {
                size_t new_cap = pd->body_capacity * 2;
                if (new_cap < needed) new_cap = needed;
                char *new_body = (char*)realloc(pd->body, new_cap);
                if (!new_body) return MHD_NO;
                pd->body = new_body;
                pd->body_capacity = new_cap;
            }
            // 把上传数据追加到 body
            memcpy(pd->body + pd->body_size, upload_data, *upload_data_size);
            pd->body_size += *upload_data_size;
            pd->body[pd->body_size] = '\0';

            // 关键：把 upload_data_size 置零，告诉 MHD 数据已消费
            *upload_data_size = 0;
            return MHD_YES;
        }

        // upload_data_size == 0：所有 POST 数据已接收，处理请求
        char *body = pd->body;
        char *response_json = NULL;

        if (strcmp(url, "/api/user/register") == 0) {
            response_json = auth_register(body);
        }
        else if (strcmp(url, "/api/login/confirm") == 0) {
            response_json = auth_confirm_login(body);
        }
        else if (strcmp(url, "/api/favorites/sync") == 0) {
            response_json = favorite_sync(body);
        }
        else {
            response_json = utils_json_error(-1, "未知接口");
        }

        // 清理
        free(pd->body);
        free(pd);
        *con_cls = NULL;

        if (response_json) {
            int ret = api_send_json(connection, 200, response_json);
            free(response_json);
            return ret;
        }
        return MHD_NO;
    }

    // ========= GET 请求 =========
    if (strcmp(method, "GET") == 0) {
        const char *query = MHD_lookup_connection_value(
            connection, MHD_GET_ARGUMENT_KIND, NULL);

        char query_str[1024] = {0};
        if (query) {
            strncpy(query_str, query, sizeof(query_str) - 1);
        }

        char *response_json = NULL;

        // 路由：请求登录token
        if (strcmp(url, "/api/login/token") == 0) {
            response_json = auth_request_token(G_SERVER_BASE_URL);
        }
        // 路由：检查登录状态
        else if (strcmp(url, "/api/login/check") == 0) {
            char *token = get_query_value(query_str, "token");
            response_json = auth_check_login(token);
            free(token);
        }
        // 路由：获取喜欢音乐列表
        else if (strcmp(url, "/api/favorites") == 0) {
            response_json = favorite_get_list(query_str);
        }
        // 路由：二维码确认页面
        else if (strncmp(url, "/qr/", 4) == 0) {
            char token[65] = {0};
            if (parse_qr_token(url, token, sizeof(token)) == 0) {
                // GET 请求访问 /qr/xxx，返回HTML页面
                // 清理 con_cls
                free(pd->body);
                free(pd);
                *con_cls = NULL;
                return send_qr_html(connection, token);
            }
        }
        else {
            response_json = utils_json_error(-1, "未知接口");
        }

        // 清理
        free(pd->body);
        free(pd);
        *con_cls = NULL;

        if (response_json) {
            int ret = api_send_json(connection, 200, response_json);
            free(response_json);
            return ret;
        }
        return MHD_NO;
    }

    // ========= DELETE 请求 =========
    if (strcmp(method, "DELETE") == 0) {
        const char *query = MHD_lookup_connection_value(
            connection, MHD_GET_ARGUMENT_KIND, NULL);

        char query_str[1024] = {0};
        if (query) {
            strncpy(query_str, query, sizeof(query_str) - 1);
        }

        char *response_json = favorite_remove(query_str);

        // 清理
        free(pd->body);
        free(pd);
        *con_cls = NULL;

        if (response_json) {
            int ret = api_send_json(connection, 200, response_json);
            free(response_json);
            return ret;
        }
        return MHD_NO;
    }

    // 清理
    free(pd->body);
    free(pd);
    *con_cls = NULL;

    return MHD_NO;
}
"""

with open("api.c", "w", encoding="utf-8") as f:
    f.write(content)

print("api.c 生成成功！")
