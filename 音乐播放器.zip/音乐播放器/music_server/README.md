# 音乐播放器服务器

C语言编写的轻量级音乐播放器后端服务器，提供用户注册、扫码登录、喜欢音乐同步等功能。

## 功能特性

- ✓ 用户注册与密码认证（SHA256加密）
- ✓ 扫码登录（二维码 + Token轮询机制）
- ✓ 喜欢音乐云端同步（多设备合并）
- ✓ RESTful API接口
- ✓ MySQL数据库存储

## 技术栈

| 组件 | 技术 |
|------|------|
| HTTP服务器 | libmicrohttpd |
| 数据库 | MySQL 5.7+ |
| JSON处理 | cJSON |
| 密码加密 | OpenSSL (SHA256) |
| UUID生成 | libuuid |

## 环境准备（Ubuntu 16.04）

### 1. 安装依赖

```bash
# 安装MySQL
sudo apt-get install mysql-server libmysqlclient-dev

# 安装其他依赖
sudo apt-get install libmicrohttpd-dev uuid-dev libssl-dev

# 编译安装cJSON
git clone https://github.com/DaveGamble/cJSON.git
cd cJSON
mkdir build && cd build
cmake ..
make
sudo make install
sudo ldconfig
```

### 2. 初始化数据库

```bash
# 登录MySQL
mysql -u root -p

# 执行初始化脚本
mysql -u root -p < init_db.sql
```

### 3. 修改配置

编辑 `src/main.c`，修改数据库密码：

```c
#define DB_PASS "your_mysql_password"  // 改成你的MySQL密码
```

编辑 `src/api.c`，修改服务器IP：

```c
static const char *G_SERVER_BASE_URL = "http://192.168.1.100:8080";  // 改成你的虚拟机IP
```

## 编译与运行

```bash
# 编译
make

# 运行
./music_server

# 或使用make run
make run
```

## API接口文档

### 1. 用户注册

```
POST /api/user/register
Content-Type: application/json

{
    "username": "test",
    "password": "123456"
}
```

### 2. 请求登录Token

```
GET /api/login/token
```

响应：
```json
{
    "code": 0,
    "data": {
        "token": "abc123...",
        "qr_url": "http://192.168.1.100:8080/qr/abc123..."
    }
}
```

### 3. 确认登录（手机端）

```
POST /api/login/confirm
Content-Type: application/json

{
    "token": "abc123...",
    "username": "test",
    "password": "123456"
}
```

### 4. 检查登录状态（客户端轮询）

```
GET /api/login/check?token=abc123...
```

### 5. 获取喜欢音乐列表

```
GET /api/favorites?user_id=xxx
```

### 6. 同步喜欢音乐

```
POST /api/favorites/sync
Content-Type: application/json

{
    "user_id": "xxx",
    "songs": [
        {
            "id": "123",
            "name": "歌曲名",
            "artist": "歌手",
            "album": "专辑",
            "duration": "03:45",
            "type": 1,
            "picUrl": "http://..."
        }
    ]
}
```

### 7. 删除喜欢音乐

```
DELETE /api/favorites?id=123&user_id=xxx&type=1
```

## 目录结构

```
music_server/
├── src/
│   ├── main.c           # 主入口
│   ├── db.c / db.h      # 数据库操作
│   ├── utils.c / utils.h # 工具函数
│   ├── auth.c / auth.h  # 认证模块
│   ├── favorite.c/h     # 喜欢音乐模块
│   └── api.c / api.h    # HTTP路由
├── static/
│   └── qr_page.html     # 扫码确认页面
├── init_db.sql          # 数据库初始化脚本
├── Makefile
└── README.md
```

## 客户端集成

在Qt客户端中修改 `loginmanager.cpp`：

```cpp
void LoginManager::requestLoginToken() {
    // 请求服务器获取token
    QNetworkRequest request(QUrl("http://192.168.1.100:8080/api/login/token"));
    // ... 处理响应，生成二维码
    
    // 启动定时器轮询登录状态
    // ... 每2秒请求 /api/login/check?token=xxx
}
```

## 注意事项

1. **MySQL密码**：记得修改 `src/main.c` 中的 `DB_PASS`
2. **服务器IP**：修改 `src/api.c` 中的 `G_SERVER_BASE_URL`
3. **防火墙**：确保Ubuntu防火墙开放8080端口
4. **虚拟机网络**：建议使用桥接模式，确保客户端能访问虚拟机IP

## 清理

```bash
make clean
```

## 许可

MIT License
