#include "db.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// ========== 数据库配置（根据实际修改） ==========
static const char *DB_HOST = "localhost";
static const char *DB_USER = "root";
static const char *DB_PASS = "hexin666";  // 修改为你自己的MySQL密码
static const char *DB_NAME = "music_server";
static unsigned int DB_PORT = 3306;

// ========== 数据库连接 ==========

int db_init(const char *host, const char *user, const char *password, const char *db_name, unsigned int port) {
    // 保存配置（实际项目应保存在全局变量或结构体中）
    // 这里使用mysql_library_init初始化
    if (mysql_library_init(0, NULL, NULL)) {
        fprintf(stderr, "mysql_library_init() 失败\n");
        return -1;
    }
    
    // 测试连接
    MYSQL *conn = mysql_init(NULL);
    if (!conn) {
        fprintf(stderr, "mysql_init() 失败\n");
        return -1;
    }
    
    // 使用参数或默认值
    const char *h = host ? host : DB_HOST;
    const char *u = user ? user : DB_USER;
    const char *p = password ? password : DB_PASS;
    const char *d = db_name ? db_name : DB_NAME;
    unsigned int pt = port > 0 ? port : DB_PORT;
    
    if (!mysql_real_connect(conn, h, u, p, d, pt, NULL, 0)) {
        fprintf(stderr, "连接数据库失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    mysql_close(conn);
    printf("数据库连接成功: %s@%s/%s\n", u, h, d);
    return 0;
}

void db_close(void) {
    mysql_library_end();
}

MYSQL* db_get_connection(void) {
    MYSQL *conn = mysql_init(NULL);
    if (!conn) return NULL;
    
    if (!mysql_real_connect(conn, DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT, NULL, 0)) {
        fprintf(stderr, "获取连接失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    
    // 设置字符集为utf8mb4
    mysql_set_character_set(conn, "utf8mb4");
    return conn;
}

// ========== 用户相关 ==========

char* db_user_register(const char *username, const char *password_hash) {
    if (!username || !password_hash) return NULL;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return NULL;
    
    // 生成用户UUID
    char user_id[37];
    // 使用简单方案：用UUID库生成（需要链接libuuid）
    // 这里使用用户名+时间戳的简单哈希作为ID（实际应使用UUID）
    // 为简化，使用mysql的UUID()函数
    char query[512];
    snprintf(query, sizeof(query), 
             "INSERT INTO users (user_id, username, password) "
             "SELECT UUID(), '%s', '%s' FROM DUAL "
             "WHERE NOT EXISTS (SELECT 1 FROM users WHERE username='%s')",
             username, password_hash, username);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "注册失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    
    // 检查是否插入成功
    if (mysql_affected_rows(conn) == 0) {
        fprintf(stderr, "用户名已存在: %s\n", username);
        mysql_close(conn);
        return NULL;
    }
    
    // 查询刚插入的用户ID
    snprintf(query, sizeof(query),
             "SELECT user_id FROM users WHERE username='%s'", username);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "查询用户ID失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    
    MYSQL_RES *res = mysql_store_result(conn);
    MYSQL_ROW row = mysql_fetch_row(res);
    char *result = NULL;
    if (row && row[0]) {
        result = strdup(row[0]);
    }
    mysql_free_result(res);
    mysql_close(conn);
    return result;
}

int db_user_get_by_username(const char *username, char *user_id, char *password_hash) {
    if (!username || !user_id || !password_hash) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[256];
    snprintf(query, sizeof(query),
             "SELECT user_id, password FROM users WHERE username='%s' LIMIT 1",
             username);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "查询用户失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    MYSQL_RES *res = mysql_store_result(conn);
    MYSQL_ROW row = mysql_fetch_row(res);
    int ret = -1;
    if (row && row[0] && row[1]) {
        strcpy(user_id, row[0]);
        strcpy(password_hash, row[1]);
        ret = 0;
    }
    mysql_free_result(res);
    mysql_close(conn);
    return ret;
}

cJSON* db_user_get_by_id(const char *user_id) {
    if (!user_id) return NULL;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return NULL;
    
    char query[256];
    snprintf(query, sizeof(query),
             "SELECT user_id, username, avatar_url FROM users WHERE user_id='%s' LIMIT 1",
             user_id);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "查询用户失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    
    MYSQL_RES *res = mysql_store_result(conn);
    MYSQL_ROW row = mysql_fetch_row(res);
    cJSON *user_json = NULL;
    if (row && row[0]) {
        user_json = cJSON_CreateObject();
        cJSON_AddStringToObject(user_json, "user_id", row[0]);
        cJSON_AddStringToObject(user_json, "username", row[1] ? row[1] : "");
        cJSON_AddStringToObject(user_json, "avatar_url", row[2] ? row[2] : "");
    }
    mysql_free_result(res);
    mysql_close(conn);
    return user_json;
}

int db_user_update_avatar(const char *user_id, const char *avatar_url) {
    if (!user_id || !avatar_url) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[512];
    snprintf(query, sizeof(query),
             "UPDATE users SET avatar_url='%s' WHERE user_id='%s'",
             avatar_url, user_id);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "更新头像失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    mysql_close(conn);
    return 0;
}

// ========== Token相关 ==========

char* db_token_create(const char *token, int ttl_seconds) {
    if (!token) return NULL;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return NULL;
    
    char query[512];
    snprintf(query, sizeof(query),
             "INSERT INTO login_tokens (token, status, created_at) "
             "VALUES ('%s', 0, NOW())",
             token);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "创建token失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    
    mysql_close(conn);
    return strdup(token);
}

int db_token_confirm(const char *token, const char *user_id) {
    if (!token || !user_id) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[512];
    snprintf(query, sizeof(query),
             "UPDATE login_tokens SET user_id='%s', status=1, confirmed_at=NOW() "
             "WHERE token='%s' AND status=0",
             user_id, token);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "确认token失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    int ret = (mysql_affected_rows(conn) > 0) ? 0 : -1;
    mysql_close(conn);
    return ret;
}

int db_token_check(const char *token, char *user_id_buf) {
    if (!token) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[512];
    snprintf(query, sizeof(query),
             "SELECT status, user_id FROM login_tokens WHERE token='%s' LIMIT 1",
             token);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "查询token失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    MYSQL_RES *res = mysql_store_result(conn);
    MYSQL_ROW row = mysql_fetch_row(res);
    int status = -1;
    
    if (row && row[0]) {
        status = atoi(row[0]);
        if (status == 1 && user_id_buf && row[1]) {
            strcpy(user_id_buf, row[1]);
        }
    }
    
    mysql_free_result(res);
    
    // 清理过期token（超过10分钟）
    snprintf(query, sizeof(query),
             "DELETE FROM login_tokens WHERE created_at < NOW() - INTERVAL 10 MINUTE");
    mysql_query(conn, query);
    
    mysql_close(conn);
    return status;
}

// ========== 喜欢音乐相关 ==========

int db_favorite_add(const char *user_id, const char *song_id, const char *song_name,
                    const char *artist, const char *album, const char *duration,
                    int type, const char *pic_url) {
    if (!user_id || !song_id || !song_name) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[1024];
    snprintf(query, sizeof(query),
             "INSERT IGNORE INTO favorites (user_id, song_id, song_name, artist, album, duration, type, pic_url) "
             "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', %d, '%s')",
             user_id, song_id, song_name,
             artist ? artist : "",
             album ? album : "",
             duration ? duration : "",
             type,
             pic_url ? pic_url : "");
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "添加喜欢失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    mysql_close(conn);
    return 0;
}

int db_favorite_remove(const char *user_id, const char *song_id, int type) {
    if (!user_id || !song_id) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[512];
    snprintf(query, sizeof(query),
             "DELETE FROM favorites WHERE user_id='%s' AND song_id='%s' AND type=%d",
             user_id, song_id, type);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "删除喜欢失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    mysql_close(conn);
    return 0;
}

cJSON* db_favorite_get_list(const char *user_id) {
    if (!user_id) return NULL;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return NULL;
    
    char query[256];
    snprintf(query, sizeof(query),
             "SELECT song_id, song_name, artist, album, duration, type, pic_url "
             "FROM favorites WHERE user_id='%s' ORDER BY added_at DESC",
             user_id);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "查询喜欢列表失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    
    MYSQL_RES *res = mysql_store_result(conn);
    MYSQL_ROW row;
    cJSON *array = cJSON_CreateArray();
    
    while ((row = mysql_fetch_row(res)) != NULL) {
        cJSON *item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "id", row[0] ? row[0] : "");
        cJSON_AddStringToObject(item, "name", row[1] ? row[1] : "");
        cJSON_AddStringToObject(item, "artist", row[2] ? row[2] : "");
        cJSON_AddStringToObject(item, "album", row[3] ? row[3] : "");
        cJSON_AddStringToObject(item, "duration", row[4] ? row[4] : "");
        cJSON_AddNumberToObject(item, "type", row[5] ? atoi(row[5]) : 1);
        cJSON_AddStringToObject(item, "picUrl", row[6] ? row[6] : "");
        cJSON_AddItemToArray(array, item);
    }
    
    mysql_free_result(res);
    mysql_close(conn);
    return array;
}

int db_favorite_sync(const char *user_id, cJSON *songs_array) {
    if (!user_id || !songs_array) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    // 开始事务
    mysql_query(conn, "START TRANSACTION");
    
    // 先删除该用户所有记录（简单同步策略：用云端覆盖本地）
    char query[512];
    snprintf(query, sizeof(query),
             "DELETE FROM favorites WHERE user_id='%s'", user_id);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "删除旧记录失败: %s\n", mysql_error(conn));
        mysql_query(conn, "ROLLBACK");
        mysql_close(conn);
        return -1;
    }
    
    // 批量插入
    int count = 0;
    int array_size = cJSON_GetArraySize(songs_array);
    for (int i = 0; i < array_size; i++) {
        cJSON *item = cJSON_GetArrayItem(songs_array, i);
        if (!item) continue;
        
        cJSON *id = cJSON_GetObjectItem(item, "id");
        cJSON *name = cJSON_GetObjectItem(item, "name");
        cJSON *artist = cJSON_GetObjectItem(item, "artist");
        cJSON *album = cJSON_GetObjectItem(item, "album");
        cJSON *duration = cJSON_GetObjectItem(item, "duration");
        cJSON *type = cJSON_GetObjectItem(item, "type");
        cJSON *picUrl = cJSON_GetObjectItem(item, "picUrl");
        
        if (!id || !name) continue;
        
        snprintf(query, sizeof(query),
                 "INSERT INTO favorites (user_id, song_id, song_name, artist, album, duration, type, pic_url) "
                 "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', %d, '%s')",
                 user_id,
                 id->valuestring,
                 name->valuestring,
                 artist ? artist->valuestring : "",
                 album ? album->valuestring : "",
                 duration ? duration->valuestring : "",
                 type ? type->valueint : 1,
                 picUrl ? picUrl->valuestring : "");
        
        if (mysql_query(conn, query) == 0) {
            count++;
        }
    }
    
    mysql_query(conn, "COMMIT");
    mysql_close(conn);
    return count;
}

// ========== 下载记录相关 ==========

int db_download_add(const char *user_id, const char *song_id, const char *song_name,
                     const char *artist, const char *album, const char *duration,
                     int type, const char *pic_url, const char *save_path,
                     long long file_size, const char *finish_time) {
    if (!user_id || !song_id || !song_name) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[1024];
    snprintf(query, sizeof(query),
             "INSERT INTO downloads (user_id, song_id, song_name, artist, album, duration, type, pic_url, save_path, file_size, finish_time) "
             "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', %lld, '%s') "
             "ON DUPLICATE KEY UPDATE "
             "song_name=VALUES(song_name), artist=VALUES(artist), album=VALUES(album), "
             "duration=VALUES(duration), pic_url=VALUES(pic_url), save_path=VALUES(save_path), "
             "file_size=VALUES(file_size), finish_time=VALUES(finish_time)",
             user_id, song_id, song_name,
             artist ? artist : "",
             album ? album : "",
             duration ? duration : "",
             type,
             pic_url ? pic_url : "",
             save_path ? save_path : "",
             file_size,
             finish_time ? finish_time : "");
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "添加下载记录失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    mysql_close(conn);
    return 0;
}

int db_download_remove(const char *user_id, const char *song_id, int type) {
    if (!user_id || !song_id) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    char query[512];
    snprintf(query, sizeof(query),
             "DELETE FROM downloads WHERE user_id='%s' AND song_id='%s' AND type=%d",
             user_id, song_id, type);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "删除下载记录失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return -1;
    }
    
    mysql_close(conn);
    return 0;
}

cJSON* db_download_get_list(const char *user_id) {
    if (!user_id) return NULL;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return NULL;
    
    char query[256];
    snprintf(query, sizeof(query),
             "SELECT song_id, song_name, artist, album, duration, type, pic_url, save_path, file_size, finish_time "
             "FROM downloads WHERE user_id='%s' ORDER BY finish_time DESC",
             user_id);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "查询下载记录失败: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    
    MYSQL_RES *res = mysql_store_result(conn);
    MYSQL_ROW row;
    cJSON *array = cJSON_CreateArray();
    
    while ((row = mysql_fetch_row(res)) != NULL) {
        cJSON *item = cJSON_CreateObject();
        cJSON_AddStringToObject(item, "song_id", row[0] ? row[0] : "");
        cJSON_AddStringToObject(item, "song_name", row[1] ? row[1] : "");
        cJSON_AddStringToObject(item, "artist", row[2] ? row[2] : "");
        cJSON_AddStringToObject(item, "album", row[3] ? row[3] : "");
        cJSON_AddStringToObject(item, "duration", row[4] ? row[4] : "");
        cJSON_AddNumberToObject(item, "type", row[5] ? atoi(row[5]) : 1);
        cJSON_AddStringToObject(item, "pic_url", row[6] ? row[6] : "");
        cJSON_AddStringToObject(item, "save_path", row[7] ? row[7] : "");
        cJSON_AddNumberToObject(item, "file_size", row[8] ? atoll(row[8]) : 0);
        cJSON_AddStringToObject(item, "finish_time", row[9] ? row[9] : "");
        cJSON_AddItemToArray(array, item);
    }
    
    mysql_free_result(res);
    mysql_close(conn);
    return array;
}

int db_download_sync(const char *user_id, cJSON *downloads_array) {
    if (!user_id || !downloads_array) return -1;
    
    MYSQL *conn = db_get_connection();
    if (!conn) return -1;
    
    // 开始事务
    mysql_query(conn, "START TRANSACTION");
    
    // 先删除该用户所有记录（简单同步策略：用云端覆盖本地）
    char query[512];
    snprintf(query, sizeof(query),
             "DELETE FROM downloads WHERE user_id='%s'", user_id);
    
    if (mysql_query(conn, query)) {
        fprintf(stderr, "删除旧下载记录失败: %s\n", mysql_error(conn));
        mysql_query(conn, "ROLLBACK");
        mysql_close(conn);
        return -1;
    }
    
    // 批量插入
    int count = 0;
    int array_size = cJSON_GetArraySize(downloads_array);
    for (int i = 0; i < array_size; i++) {
        cJSON *item = cJSON_GetArrayItem(downloads_array, i);
        if (!item) continue;
        
        cJSON *song_id = cJSON_GetObjectItem(item, "song_id");
        cJSON *song_name = cJSON_GetObjectItem(item, "song_name");
        cJSON *artist = cJSON_GetObjectItem(item, "artist");
        cJSON *album = cJSON_GetObjectItem(item, "album");
        cJSON *duration = cJSON_GetObjectItem(item, "duration");
        cJSON *type = cJSON_GetObjectItem(item, "type");
        cJSON *pic_url = cJSON_GetObjectItem(item, "pic_url");
        cJSON *save_path = cJSON_GetObjectItem(item, "save_path");
        cJSON *file_size = cJSON_GetObjectItem(item, "file_size");
        cJSON *finish_time = cJSON_GetObjectItem(item, "finish_time");
        
        if (!song_id || !song_name) continue;
        
        snprintf(query, sizeof(query),
                 "INSERT INTO downloads (user_id, song_id, song_name, artist, album, duration, type, pic_url, save_path, file_size, finish_time) "
                 "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', %lld, '%s')",
                 user_id,
                 song_id->valuestring,
                 song_name->valuestring,
                 artist ? artist->valuestring : "",
                 album ? album->valuestring : "",
                 duration ? duration->valuestring : "",
                 type ? type->valueint : 1,
                 pic_url ? pic_url->valuestring : "",
                 save_path ? save_path->valuestring : "",
                 file_size ? (long long)file_size->valuedouble : 0,
                 finish_time ? finish_time->valuestring : "");
        
        if (mysql_query(conn, query) == 0) {
            count++;
        }
    }
    
    mysql_query(conn, "COMMIT");
    mysql_close(conn);
    return count;
}
