#include <microhttpd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include "db.h"
#include "api.h"

// ========== 服务器配置 ==========
#define SERVER_PORT 8080
#define SERVER_HOST "0.0.0.0"

// ========== 数据库配置（根据实际修改） ==========
#define DB_HOST "localhost"
#define DB_USER "root"
#define DB_PASS "your_password"
#define DB_NAME "music_server"
#define DB_PORT 3306

// ========== 服务器状态 ==========
static struct MHD_Daemon *g_daemon = NULL;

// 优雅退出处理
static void signal_handler(int sig) {
    (void)sig;
    if (g_daemon) {
        printf("\n收到退出信号，正在关闭服务器...\n");
        MHD_stop_daemon(g_daemon);
        g_daemon = NULL;
    }
    db_close();
    exit(0);
}

int main(int argc, char *argv[]) {
    (void)argc;
    (void)argv;
    
    // 注册信号处理器
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    printf("========================================\n");
    printf("  音乐播放器服务器 v1.0\n");
    printf("========================================\n\n");
    
    // 初始化数据库
    printf("[1/3] 正在连接数据库...\n");
    if (db_init(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT) != 0) {
        fprintf(stderr, "  ✗ 数据库连接失败\n");
        fprintf(stderr, "  请修改 src/main.c 中的数据库配置\n");
        fprintf(stderr, "  DB_HOST=%s\n", DB_HOST);
        fprintf(stderr, "  DB_USER=%s\n", DB_USER);
        fprintf(stderr, "  DB_NAME=%s\n", DB_NAME);
        return 1;
    }
    printf("  ✓ 数据库连接成功\n\n");
    
    // 启动HTTP服务器
    printf("[2/3] 正在启动HTTP服务器...\n");
    g_daemon = MHD_start_daemon(
        MHD_USE_SELECT_INTERNALLY,
        SERVER_PORT,
        NULL,  // 访问控制回调
        NULL,
        &api_handler,  // 请求处理回调
        NULL,
        MHD_OPTION_END
    );
    
    if (!g_daemon) {
        fprintf(stderr, "  ✗ 服务器启动失败\n");
        db_close();
        return 1;
    }
    
    printf("  ✓ 服务器启动成功\n");
    printf("  监听端口: %d\n", SERVER_PORT);
    printf("  访问地址: http://localhost:8080\n");
    printf("\n");
    
    // 打印API接口列表
    printf("[3/3] 可用API接口:\n");
    printf("  POST   /api/user/register       用户注册\n");
    printf("  GET    /api/login/token         请求登录token\n");
    printf("  POST   /api/login/confirm      确认登录\n");
    printf("  GET    /api/login/check?token= 检查登录状态\n");
    printf("  GET    /api/favorites?user_id= 获取喜欢列表\n");
    printf("  POST   /api/favorites/sync      同步喜欢列表\n");
    printf("  DELETE /api/favorites           删除喜欢音乐\n");
    printf("  GET    /qr/{token}             扫码确认页面\n");
    printf("\n");
    printf("服务器运行中... 按 Ctrl+C 停止\n\n");
    
    // 主循环
    while (1) {
        sleep(1);
    }
    
    // 清理（不会执行到这里）
    if (g_daemon) {
        MHD_stop_daemon(g_daemon);
    }
    db_close();
    
    return 0;
}
