#include "favorite.h"
#include "db.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 解析URL查询字符串中的参数值
// 调用者需free返回值
static char* get_query_param(const char *query, const char *key) {
    if (!query || !key) return NULL;
    
    char *q = strdup(query);
    if (!q) return NULL;
    
    char *saveptr = NULL;
    char *token = strtok_r(q, "&", &saveptr);
    char *result = NULL;
    
    while (token != NULL) {
        char *eq = strchr(token, '=');
        if (eq) {
            *eq = '\0';
            if (strcmp(token, key) == 0) {
                result = strdup(eq + 1);
                break;
            }
        }
        token = strtok_r(NULL, "&", &saveptr);
    }
    
    free(q);
    return result;
}

// 添加喜欢音乐
char* favorite_add(const char *body) {
    if (!body) {
        return utils_json_error(-1, "请求体为空");
    }
    
    cJSON *json = cJSON_Parse(body);
    if (!json) {
        return utils_json_error(-1, "JSON解析失败");
    }
    
    cJSON *user_id_obj = cJSON_GetObjectItem(json, "user_id");
    cJSON *id_obj = cJSON_GetObjectItem(json, "id");
    cJSON *name_obj = cJSON_GetObjectItem(json, "name");
    
    if (!user_id_obj || !id_obj || !name_obj ||
        !user_id_obj->valuestring || !id_obj->valuestring || !name_obj->valuestring) {
        cJSON_Delete(json);
        return utils_json_error(-1, "缺少必要参数");
    }
    
    cJSON *artist_obj = cJSON_GetObjectItem(json, "artist");
    cJSON *album_obj = cJSON_GetObjectItem(json, "album");
    cJSON *duration_obj = cJSON_GetObjectItem(json, "duration");
    cJSON *type_obj = cJSON_GetObjectItem(json, "type");
    cJSON *picUrl_obj = cJSON_GetObjectItem(json, "picUrl");
    
    int ret = db_favorite_add(
        user_id_obj->valuestring,
        id_obj->valuestring,
        name_obj->valuestring,
        artist_obj ? artist_obj->valuestring : "",
        album_obj ? album_obj->valuestring : "",
        duration_obj ? duration_obj->valuestring : "",
        type_obj ? type_obj->valueint : 1,
        picUrl_obj ? picUrl_obj->valuestring : ""
    );
    
    cJSON_Delete(json);
    
    if (ret != 0) {
        return utils_json_error(-1, "添加喜欢失败");
    }
    
    return utils_json_success("{\"message\":\"添加成功\"}");
}

// 删除喜欢音乐（直接接收参数）
char* favorite_remove(const char *user_id, const char *song_id, int type) {
    if (!user_id || !song_id) {
        return utils_json_error(-1, "缺少user_id或song_id");
    }
    
    int ret = db_favorite_remove(user_id, song_id, type);
    
    if (ret != 0) {
        return utils_json_error(-1, "删除喜欢失败");
    }
    
    return utils_json_success("{\"message\":\"删除成功\"}");
}

// 获取喜欢音乐列表（直接接收user_id）
char* favorite_get_list(const char *user_id) {
    if (!user_id) {
        return utils_json_error(-1, "缺少user_id");
    }
    
    cJSON *songs_array = db_favorite_get_list(user_id);
    
    if (!songs_array) {
        return utils_json_error(-1, "获取列表失败");
    }
    
    char *array_str = cJSON_PrintUnformatted(songs_array);
    cJSON_Delete(songs_array);
    
    char *data = (char*)malloc(strlen(array_str) + 16);
    if (data) {
        sprintf(data, "{\"songs\":%s}", array_str);
    }
    free(array_str);
    
    char *response = utils_json_success(data);
    free(data);
    return response;
}

// 同步喜欢音乐（批量）
char* favorite_sync(const char *body) {
    if (!body) {
        return utils_json_error(-1, "请求体为空");
    }
    
    cJSON *json = cJSON_Parse(body);
    if (!json) {
        return utils_json_error(-1, "JSON解析失败");
    }
    
    cJSON *user_id_obj = cJSON_GetObjectItem(json, "user_id");
    cJSON *songs_obj = cJSON_GetObjectItem(json, "songs");
    
    if (!user_id_obj || !user_id_obj->valuestring || !songs_obj) {
        cJSON_Delete(json);
        return utils_json_error(-1, "缺少user_id或songs");
    }
    
    int count = db_favorite_sync(user_id_obj->valuestring, songs_obj);
    cJSON_Delete(json);
    
    if (count < 0) {
        return utils_json_error(-1, "同步失败");
    }
    
    char data[64];
    snprintf(data, sizeof(data), "{\"count\":%d}", count);
    return utils_json_success(data);
}
