#ifndef AUTH_H
#define AUTH_H

#include "cJSON.h"

// ========== 用户注册 ==========

// 处理用户注册请求
// body: POST请求的JSON body，格式: {"username":"xxx","password":"xxx"}
// 返回: 动态分配的JSON响应字符串，需调用者free
char* auth_register(const char *body);

// ========== 登录Token管理 ==========

// 请求登录token（客户端调用）
// 返回: 动态分配的JSON响应字符串，格式: {"code":0,"token":"xxx","qr_url":"http://..."}
// 需调用者free
// server_base_url: 服务器基础URL（如 "http://192.168.1.100:8080"）
char* auth_request_token(const char *server_base_url);

// 确认登录（手机端调用，扫码后点击确认）
// body: POST请求的JSON body，格式: {"token":"xxx","username":"xxx","password":"xxx"}
// 返回: 动态分配的JSON响应字符串，需调用者free
char* auth_confirm_login(const char *body);

// 检查登录状态（客户端轮询）
// token: 登录token
// 返回: 动态分配的JSON响应字符串
// 未确认: {"code":0,"status":0}
// 已确认: {"code":0,"status":1,"user":{"user_id":"xxx","username":"xxx"}}
// 失败:   {"code":-1,"message":"xxx"}
// 需调用者free
char* auth_check_login(const char *token);

#endif // AUTH_H
