#ifndef API_H
#define API_H

#include <microhttpd.h>

// ========== API路由入口 ==========

// libmicrohttpd 请求处理回调函数
// 这是服务器的核心入口，所有HTTP请求都经过这里分发
int api_handler(void *cls,
               struct MHD_Connection *connection,
               const char *url,
               const char *method,
               const char *version,
               const char *upload_data,
               size_t *upload_data_size,
               void **con_cls);

// ========== 响应辅助函数 ==========

// 发送JSON响应
// status_code: HTTP状态码（如200, 400, 500）
// json_body: JSON字符串（函数内部会复制，调用者需自行free）
int api_send_json(struct MHD_Connection *connection,
                 int status_code,
                 const char *json_body);

// 发送文件内容（用于二维码确认页面）
int api_send_file(struct MHD_Connection *connection,
                  const char *file_path);

// ========== URL路由解析辅助 ==========

// 匹配URL模式，支持参数提取
// 例如: pattern="/qr/{token}", url="/qr/abc123", 则token="abc123"
// 返回0表示匹配成功
int api_match_route(const char *pattern, const char *url, char *param_buf, size_t param_buf_size);

#endif // API_H
