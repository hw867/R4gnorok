#ifndef FAVORITE_H
#define FAVORITE_H

#include "cJSON.h"

// ========== 喜欢音乐管理 ==========

// 添加喜欢音乐
// body: POST请求的JSON body，格式: {"user_id":"xxx","id":"xxx","name":"xxx",...}
// 返回: 动态分配的JSON响应字符串，需调用者free
char* favorite_add(const char *body);

// 删除喜欢音乐
// user_id: 用户ID, song_id: 歌曲ID, type: 歌曲类型
// 返回: 动态分配的JSON响应字符串，需调用者free
char* favorite_remove(const char *user_id, const char *song_id, int type);

// 获取喜欢音乐列表
// user_id: 用户ID
// 返回: 动态分配的JSON响应字符串，需调用者free
char* favorite_get_list(const char *user_id);

// 同步喜欢音乐（批量，覆盖式）
// body: POST请求的JSON body，格式: {"user_id":"xxx","songs":[...]}
// 返回: 动态分配的JSON响应字符串，需调用者free
char* favorite_sync(const char *body);

#endif // FAVORITE_H
