#ifndef UTILS_H
#define UTILS_H

#include <microhttpd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <openssl/sha.h>

// 生成UUID字符串，调用者负责free
char* utils_generate_uuid(void);

// 对密码进行SHA256哈希，返回十六进制字符串（64字节+'\0'）
// 调用者负责free
char* utils_sha256(const char *password);

// 获取当前时间戳字符串，格式: YYYY-MM-DD HH:MM:SS
// 调用者负责free
char* utils_current_time(void);

// 生成JSON格式的错误响应
// 调用者负责free
char* utils_json_error(int code, const char *message);

// 生成JSON格式的成功响应（带data）
// 调用者负责free
char* utils_json_success(const char *data);

// URL解码（简单实现，仅处理%XX）
// 调用者负责free
char* utils_url_decode(const char *str);

// 获取POST请求的body数据（从connection的wp中读取）
// 需要在libmicrohttpd的MHD_AccessHandlerCallback中使用
char* utils_read_post_data(void *con_cls, struct MHD_Connection *connection);

// 生成随机token字符串（用于登录token）
// len: token长度（字节），实际十六进制字符串长度为len*2
// 调用者负责free
char* utils_generate_token(int len);

#endif // UTILS_H
