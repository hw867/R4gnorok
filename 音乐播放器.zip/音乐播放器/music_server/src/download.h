#ifndef DOWNLOAD_H
#define DOWNLOAD_H

#include "cJSON.h"

// ========== 下载记录管理 ==========

// 添加下载记录
// body: POST请求的JSON body，格式: {"user_id":"xxx","song_id":"xxx","song_name":"xxx",...}
// 返回: 动态分配的JSON响应字符串，需调用者free
char* download_add(const char *body);

// 删除下载记录
// user_id: 用户ID, song_id: 歌曲ID, type: 歌曲类型
// 返回: 动态分配的JSON响应字符串，需调用者free
char* download_remove(const char *user_id, const char *song_id, int type);

// 获取下载记录列表
// user_id: 用户ID
// 返回: 动态分配的JSON响应字符串，需调用者free
char* download_get_list(const char *user_id);

// 同步下载记录（批量，覆盖式）
// body: POST请求的JSON body，格式: {"user_id":"xxx","downloads":[...]}
// 返回: 动态分配的JSON响应字符串，需调用者free
char* download_sync(const char *body);

#endif // DOWNLOAD_H
