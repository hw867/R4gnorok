#include "utils.h"
#include <openssl/sha.h>
#include <uuid/uuid.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// 生成UUID字符串，调用者负责free
char* utils_generate_uuid(void) {
    uuid_t bin;
    uuid_generate(bin);
    char *str = (char*)malloc(37);  // UUID字符串固定36字符+'\0'
    if (str) {
        uuid_unparse(bin, str);
    }
    return str;
}

// 对密码进行SHA256哈希，返回十六进制字符串（65字节，含'\0'）
// 使用高层API，避免EVP_MD_CTX宏替换问题
char* utils_sha256(const char *password) {
    if (!password) return NULL;
    
    // 使用高层API，直接调用SHA256()
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char*)password, strlen(password), hash);
    
    // 转为十六进制字符串
    char *result = (char*)malloc(65);
    if (!result) return NULL;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        sprintf(result + (i * 2), "%02x", hash[i]);
    }
    result[64] = '\0';
    return result;
}

// 获取当前时间戳字符串，格式: YYYY-MM-DD HH:MM:SS
char* utils_current_time(void) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char *buf = (char*)malloc(20);
    if (buf) {
        strftime(buf, 20, "%Y-%m-%d %H:%M:%S", t);
    }
    return buf;
}

// 生成JSON格式的错误响应
char* utils_json_error(int code, const char *message) {
    if (!message) message = "";
    // {"code":xxx,"message":"xxx"}
    int len = snprintf(NULL, 0, "{\"code\":%d,\"message\":\"%s\"}", code, message) + 1;
    char *json = (char*)malloc(len);
    if (json) {
        snprintf(json, len, "{\"code\":%d,\"message\":\"%s\"}", code, message);
    }
    return json;
}

// 生成JSON格式的成功响应（带data，data应为已格式化的JSON片段）
char* utils_json_success(const char *data) {
    if (!data) data = "null";
    // {"code":0,"data":xxx}
    int len = snprintf(NULL, 0, "{\"code\":0,\"data\":%s}", data) + 1;
    char *json = (char*)malloc(len);
    if (json) {
        snprintf(json, len, "{\"code\":0,\"data\":%s}", data);
    }
    return json;
}

// URL解码（简单实现，处理%XX和+）
char* utils_url_decode(const char *str) {
    if (!str) return NULL;
    
    int len = strlen(str);
    char *result = (char*)malloc(len + 1);
    if (!result) return NULL;
    
    int i = 0, j = 0;
    while (i < len) {
        if (str[i] == '%' && i + 2 < len &&
            isxdigit((unsigned char)str[i+1]) && isxdigit((unsigned char)str[i+2])) {
            // 解析%XX
            char hex[3] = {str[i+1], str[i+2], '\0'};
            result[j++] = (char)strtol(hex, NULL, 16);
            i += 3;
        } else if (str[i] == '+') {
            result[j++] = ' ';
            i++;
        } else {
            result[j++] = str[i++];
        }
    }
    result[j] = '\0';
    return result;
}

// 生成随机token字符串（十六进制表示）
// len: 随机字节数，输出字符串长度为len*2
char* utils_generate_token(int len) {
    if (len <= 0) len = 16;
    
    unsigned char *rand_bytes = (unsigned char*)malloc(len);
    char *token = (char*)malloc(len * 2 + 1);
    if (!rand_bytes || !token) {
        free(rand_bytes);
        free(token);
        return NULL;
    }
    
    // 使用/dev/urandom生成随机字节
    FILE *fp = fopen("/dev/urandom", "r");
    if (!fp) {
        // 降级方案：使用时间+随机数
        srand(time(NULL));
        for (int i = 0; i < len; i++) {
            rand_bytes[i] = rand() & 0xFF;
        }
    } else {
        (void)fread(rand_bytes, 1, len, fp);
        fclose(fp);
    }
    
    // 转为十六进制
    for (int i = 0; i < len; i++) {
        sprintf(token + (i * 2), "%02x", rand_bytes[i]);
    }
    token[len * 2] = '\0';
    
    free(rand_bytes);
    return token;
}
