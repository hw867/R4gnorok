#include "api.h"
#include "auth.h"
#include "favorite.h"
#include "download.h"
#include "utils.h"
#include "db.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <microhttpd.h>

// ========== 全局配置 ==========
static const char *G_SERVER_BASE_URL = "http://192.168.1.114:8080";
static const char *G_AVATAR_DIR = "./avatars/";  // 头像存储目录

// ========== 头像上传处理 ==========

// 处理头像上传
// body格式: {"user_id":"xxx","avatar_data":"base64编码的图片数据"}
static char* handle_avatar_upload(const char *body) {
    if (!body) {
        return utils_json_error(-1, "请求体为空");
    }
    
    cJSON *json = cJSON_Parse(body);
    if (!json) {
        return utils_json_error(-1, "JSON解析失败");
    }
    
    cJSON *user_id_obj = cJSON_GetObjectItem(json, "user_id");
    cJSON *avatar_data_obj = cJSON_GetObjectItem(json, "avatar_data");
    
    if (!user_id_obj || !avatar_data_obj ||
        !user_id_obj->valuestring || !avatar_data_obj->valuestring) {
        cJSON_Delete(json);
        return utils_json_error(-1, "缺少user_id或avatar_data");
    }
    
    const char *user_id = user_id_obj->valuestring;
    const char *avatar_data = avatar_data_obj->valuestring;
    
    // 生成文件名：avatar_userid_timestamp.jpg
    char filename[128];
    time_t now = time(NULL);
    snprintf(filename, sizeof(filename), "avatar_%s_%ld.jpg", user_id, now);
    
    // 确保目录存在
    system("mkdir -p ./avatars");
    
    // 构建完整路径
    char filepath[256];
    snprintf(filepath, sizeof(filepath), "%s%s", G_AVATAR_DIR, filename);
    
    // 解码Base64并保存文件
    // 简单的Base64解码（只处理标准字符）
    int data_len = strlen(avatar_data);
    unsigned char *decoded = (unsigned char*)malloc(data_len);
    if (!decoded) {
        cJSON_Delete(json);
        return utils_json_error(-1, "内存分配失败");
    }
    
    int decoded_len = 0;
    int i = 0;
    int padding = 0;
    
    // 计算padding
    if (data_len > 0 && avatar_data[data_len-1] == '=') padding++;
    if (data_len > 1 && avatar_data[data_len-2] == '=') padding++;
    
    // Base64解码
    const char *chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (int j = 0; j < data_len; j++) {
        if (avatar_data[j] == '=') continue;
        if (avatar_data[j] == ' ' || avatar_data[j] == '\n' || avatar_data[j] == '\r') continue;
        
        char *p = strchr(chars, avatar_data[j]);
        if (p) {
            decoded[decoded_len++] = p - chars;
        }
    }
    
    // 转换为实际字节
    int out_len = 0;
    unsigned char *output = (unsigned char*)malloc(data_len);
    if (!output) {
        free(decoded);
        cJSON_Delete(json);
        return utils_json_error(-1, "内存分配失败");
    }
    
    for (int j = 0; j < decoded_len; j += 4) {
        if (j + 3 < decoded_len) {
            output[out_len++] = (decoded[j] << 2) | (decoded[j+1] >> 4);
            output[out_len++] = ((decoded[j+1] & 0x0F) << 4) | (decoded[j+2] >> 2);
            output[out_len++] = ((decoded[j+2] & 0x03) << 6) | decoded[j+3];
        } else if (j + 2 < decoded_len) {
            output[out_len++] = (decoded[j] << 2) | (decoded[j+1] >> 4);
            output[out_len++] = ((decoded[j+1] & 0x0F) << 4) | (decoded[j+2] >> 2);
        } else if (j + 1 < decoded_len) {
            output[out_len++] = (decoded[j] << 2) | (decoded[j+1] >> 4);
        }
    }
    
    // 减去padding
    out_len -= padding;
    
    // 写入文件
    FILE *fp = fopen(filepath, "wb");
    if (!fp) {
        free(decoded);
        free(output);
        cJSON_Delete(json);
        return utils_json_error(-1, "无法创建头像文件");
    }
    
    fwrite(output, 1, out_len, fp);
    fclose(fp);
    
    free(decoded);
    free(output);
    
    // 构建头像URL
    char avatar_url[384];
    snprintf(avatar_url, sizeof(avatar_url), "%s/avatars/%s", G_SERVER_BASE_URL, filename);
    
    // 更新数据库
    if (db_user_update_avatar(user_id, avatar_url) != 0) {
        cJSON_Delete(json);
        return utils_json_error(-1, "更新数据库失败");
    }
    
    cJSON_Delete(json);
    
    // 返回成功响应
    char data[512];
    snprintf(data, sizeof(data), "{\"avatar_url\":\"%s\"}", avatar_url);
    return utils_json_success(data);
}

// ========== 响应辅助函数 ==========

int api_send_json(struct MHD_Connection *connection,
                 int status_code,
                 const char *json_body) {
    if (!connection || !json_body) return MHD_NO;

    struct MHD_Response *response = MHD_create_response_from_buffer(
        strlen(json_body),
        (void*)json_body,
        MHD_RESPMEM_MUST_COPY
    );

    if (!response) return MHD_NO;

    MHD_add_response_header(response, "Content-Type", "application/json; charset=utf-8");
    MHD_add_response_header(response, "Access-Control-Allow-Origin", "*");

    int ret = MHD_queue_response(connection, status_code, response);
    MHD_destroy_response(response);
    return ret;
}

// ========== 文件读取回调 ==========

static ssize_t file_reader_callback(void *cls,
                                    uint64_t pos,
                                    char *buf,
                                    size_t max) {
    FILE *fp = (FILE*)cls;
    if (!fp) return MHD_CONTENT_READER_END_WITH_ERROR;
    fseek(fp, (long)pos, SEEK_SET);
    size_t read_bytes = fread(buf, 1, max, fp);
    if (read_bytes == 0 && ferror(fp)) return MHD_CONTENT_READER_END_WITH_ERROR;
    if (read_bytes == 0) return MHD_CONTENT_READER_END_OF_STREAM;
    return (ssize_t)read_bytes;
}

static void file_free_callback(void *cls) {
    FILE *fp = (FILE*)cls;
    if (fp) fclose(fp);
}

int api_send_file(struct MHD_Connection *connection,
                  const char *file_path) {
    if (!connection || !file_path) return MHD_NO;

    FILE *fp = fopen(file_path, "rb");
    if (!fp) {
        const char *not_found = "404 Not Found";
        struct MHD_Response *response = MHD_create_response_from_buffer(
            strlen(not_found), (void*)not_found, MHD_RESPMEM_PERSISTENT);
        if (response) {
            MHD_add_response_header(response, "Content-Type", "text/plain");
            int ret = MHD_queue_response(connection, 404, response);
            MHD_destroy_response(response);
            return ret;
        }
        return MHD_NO;
    }

    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    struct MHD_Response *response = MHD_create_response_from_callback(
        (uint64_t)file_size,
        1024,
        &file_reader_callback,
        fp,
        &file_free_callback
    );

    if (!response) {
        fclose(fp);
        return MHD_NO;
    }

    const char *content_type = "text/html; charset=utf-8";
    if (strstr(file_path, ".css")) content_type = "text/css";
    else if (strstr(file_path, ".js")) content_type = "application/javascript";
    else if (strstr(file_path, ".png")) content_type = "image/png";
    else if (strstr(file_path, ".jpg") || strstr(file_path, ".jpeg")) content_type = "image/jpeg";

    MHD_add_response_header(response, "Content-Type", content_type);

    int ret = MHD_queue_response(connection, 200, response);
    MHD_destroy_response(response);
    return ret;
}

// ========== 发送二维码确认页面 ==========

static int send_qr_html(struct MHD_Connection *connection, const char *token) {
    if (!token) return MHD_NO;

    char html[16384];
    int len = snprintf(html, sizeof(html),
        "<!DOCTYPE html>"
        "<html><head>"
        "<meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        "<title>扫码登录</title>"
        "<style>"
        "body{font-family:sans-serif;text-align:center;padding:20px;background:#f5f5f5;margin:0;}"
        ".container{background:white;max-width:380px;margin:40px auto;padding:30px 25px;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.1);}"
        "h2{color:#333;margin-bottom:8px;}"
        "p{color:#666;font-size:14px;margin-bottom:20px;}"
        ".form-group{text-align:left;margin-bottom:16px;}"
        ".form-group label{display:block;color:#333;font-size:14px;margin-bottom:6px;font-weight:bold;}"
        ".form-group input{width:100%%;padding:10px 12px;border:1px solid #ddd;border-radius:6px;font-size:15px;box-sizing:border-box;}"
        ".form-group input:focus{outline:none;border-color:#1DB954;}"
        ".btn-confirm{width:100%%;padding:12px;font-size:16px;border:none;border-radius:6px;cursor:pointer;background:#1DB954;color:white;margin-top:8px;}"
        ".btn-confirm:active{background:#169c46;}"
        ".btn-cancel{width:100%%;padding:10px;font-size:14px;border:1px solid #ddd;background:white;color:#666;border-radius:6px;cursor:pointer;margin-top:12px;}"
        ".btn-switch{width:100%%;padding:10px;font-size:14px;border:none;background:none;color:#1DB954;cursor:pointer;margin-top:16px;}"
        ".msg{margin-top:12px;font-size:13px;}"
        ".msg.success{color:green;}"
        ".msg.error{color:red;}"
        ".form-section{display:block;}"
        ".form-section.hidden{display:none;}"
        ".switch-hint{color:#666;font-size:13px;margin-top:16px;}"
        ".switch-link{color:#1DB954;text-decoration:none;cursor:pointer;font-weight:bold;}"
        "</style>"
        "</head><body>"
        "<div class=\"container\">"
        "<h2>🎵 音乐播放器</h2>"
        
        "<!-- 登录表单 -->"
        "<div id=\"loginSection\" class=\"form-section\">"
        "<p>请登录以确认扫码</p>"
        "<form id=\"loginForm\" onsubmit=\"doLogin(event)\">"
        "<div class=\"form-group\">"
        "<label>用户名</label>"
        "<input type=\"text\" id=\"loginUsername\" placeholder=\"请输入用户名\" required autocomplete=\"username\">"
        "</div>"
        "<div class=\"form-group\">"
        "<label>密码</label>"
        "<input type=\"password\" id=\"loginPassword\" placeholder=\"请输入密码\" required autocomplete=\"current-password\">"
        "</div>"
        "<button type=\"submit\" class=\"btn-confirm\">确认登录</button>"
        "</form>"
        "<div class=\"switch-hint\">"
        "还没有账号？<a class=\"switch-link\" onclick=\"showRegister()\">立即注册</a>"
        "</div>"
        "<div class=\"msg\" id=\"loginMsg\"></div>"
        "</div>"
        
        "<!-- 注册表单 -->"
        "<div id=\"registerSection\" class=\"form-section hidden\">"
        "<p>创建新账号</p>"
        "<form id=\"registerForm\" onsubmit=\"doRegister(event)\">"
        "<div class=\"form-group\">"
        "<label>用户名</label>"
        "<input type=\"text\" id=\"regUsername\" placeholder=\"请输入用户名\" required autocomplete=\"username\">"
        "</div>"
        "<div class=\"form-group\">"
        "<label>密码</label>"
        "<input type=\"password\" id=\"regPassword\" placeholder=\"密码至少6位\" required autocomplete=\"new-password\">"
        "</div>"
        "<div class=\"form-group\">"
        "<label>确认密码</label>"
        "<input type=\"password\" id=\"regPassword2\" placeholder=\"再次输入密码\" required autocomplete=\"new-password\">"
        "</div>"
        "<button type=\"submit\" class=\"btn-confirm\">注册</button>"
        "</form>"
        "<div class=\"switch-hint\">"
        "已有账号？<a class=\"switch-link\" onclick=\"showLogin()\">立即登录</a>"
        "</div>"
        "<div class=\"msg\" id=\"regMsg\"></div>"
        "</div>"
        
        "<button class=\"btn-cancel\" onclick=\"cancelLogin()\">取消</button>"
        "</div>"
        
        "<script>"
        "function showRegister(){"
        "  document.getElementById('loginSection').classList.add('hidden');"
        "  document.getElementById('registerSection').classList.remove('hidden');"
        "  clearMsgs();"
        "}"
        "function showLogin(){"
        "  document.getElementById('registerSection').classList.add('hidden');"
        "  document.getElementById('loginSection').classList.remove('hidden');"
        "  clearMsgs();"
        "}"
        "function clearMsgs(){"
        "  document.getElementById('loginMsg').innerText='';"
        "  document.getElementById('regMsg').innerText='';"
        "}"
        "function doLogin(e){"
        "  e.preventDefault();"
        "  var u=document.getElementById('loginUsername').value.trim();"
        "  var p=document.getElementById('loginPassword').value;"
        "  var msg=document.getElementById('loginMsg');"
        "  if(!u||!p){msg.className='msg error';msg.innerText='请输入用户名和密码';return;}"
        "  msg.innerText='正在确认...';"
        "  msg.className='msg';"
        "  var xhr=new XMLHttpRequest();"
        "  xhr.open('POST','/api/login/confirm',true);"
        "  xhr.setRequestHeader('Content-Type','application/json');"
        "  xhr.onload=function(){"
        "    var res;"
        "    try{res=JSON.parse(xhr.responseText);}catch(e){msg.className='msg error';msg.innerText='服务器响应异常';return;}"
        "    if(res.code==0){"
        "      msg.className='msg success';"
        "      msg.innerText='登录成功！请在客户端查看';"
        "      document.getElementById('loginForm').style.display='none';"
        "    }else{"
        "      msg.className='msg error';"
        "      msg.innerText=res.message||'确认失败';"
        "    }"
        "  };"
        "  xhr.onerror=function(){msg.className='msg error';msg.innerText='网络错误，请重试';};"
        "  xhr.send(JSON.stringify({token:'%s',username:u,password:p}));"
        "}"
        "function doRegister(e){"
        "  e.preventDefault();"
        "  var u=document.getElementById('regUsername').value.trim();"
        "  var p=document.getElementById('regPassword').value;"
        "  var p2=document.getElementById('regPassword2').value;"
        "  var msg=document.getElementById('regMsg');"
        "  if(!u){msg.className='msg error';msg.innerText='请输入用户名';return;}"
        "  if(p.length<6){msg.className='msg error';msg.innerText='密码长度至少6位';return;}"
        "  if(p!==p2){msg.className='msg error';msg.innerText='两次密码不一致';return;}"
        "  msg.innerText='正在注册...';"
        "  msg.className='msg';"
        "  var xhr=new XMLHttpRequest();"
        "  xhr.open('POST','/api/user/register',true);"
        "  xhr.setRequestHeader('Content-Type','application/json');"
        "  xhr.onload=function(){"
        "    var res;"
        "    try{res=JSON.parse(xhr.responseText);}catch(e){msg.className='msg error';msg.innerText='服务器响应异常';return;}"
        "    if(res.code==0){"
        "      msg.className='msg success';"
        "      msg.innerText='注册成功！请使用新账号登录';"
        "      document.getElementById('regUsername').value='';"
        "      document.getElementById('regPassword').value='';"
        "      document.getElementById('regPassword2').value='';"
        "      setTimeout(function(){showLogin();document.getElementById('loginUsername').value=u;},1500);"
        "    }else{"
        "      msg.className='msg error';"
        "      msg.innerText=res.message||'注册失败';"
        "    }"
        "  };"
        "  xhr.onerror=function(){msg.className='msg error';msg.innerText='网络错误，请重试';};"
        "  xhr.send(JSON.stringify({username:u,password:p}));"
        "}"
        "function cancelLogin(){"
        "  document.getElementById('loginMsg').className='msg';"
        "  document.getElementById('loginMsg').innerText='已取消登录';"
        "  setTimeout(function(){window.close();},1000);"
        "}"
        "</script>"
        "</body></html>",
        token
    );

    if (len <= 0) return MHD_NO;

    struct MHD_Response *response = MHD_create_response_from_buffer(
        (size_t)len, html, MHD_RESPMEM_MUST_COPY);

    if (!response) return MHD_NO;

    MHD_add_response_header(response, "Content-Type", "text/html; charset=utf-8");

    int ret = MHD_queue_response(connection, 200, response);
    MHD_destroy_response(response);
    return ret;
}

// ========== URL路由解析 ==========

static int parse_qr_token(const char *url, char *token_buf, size_t buf_size) {
    if (!url || !token_buf) return -1;
    if (strncmp(url, "/qr/", 4) != 0) return -1;

    const char *token_start = url + 4;
    const char *token_end = token_start;
    while (*token_end && *token_end != '?') token_end++;

    size_t len = token_end - token_start;
    if (len == 0 || len >= buf_size) return -1;

    strncpy(token_buf, token_start, len);
    token_buf[len] = '\0';
    return 0;
}

static char* get_query_value(const char *query_string, const char *key) {
    if (!query_string || !key) return NULL;

    char *qs = strdup(query_string);
    if (!qs) return NULL;

    char *result = NULL;
    char *saveptr = NULL;
    char *token = strtok_r(qs, "&", &saveptr);

    while (token) {
        char *eq = strchr(token, '=');
        if (eq) {
            *eq = '\0';
            if (strcmp(token, key) == 0) {
                result = strdup(eq + 1);
                break;
            }
        }
        token = strtok_r(NULL, "&", &saveptr);
    }

    free(qs);
    return result;
}

// ========== POST数据读取 ==========

struct PostData {
    char *body;
    size_t body_size;
    size_t body_capacity;
};

// ========== 核心请求处理 ==========
// 正确的POST数据处理方式：
// 1. 第一次调用：初始化 PostData，存入 con_cls，返回 MHD_YES
// 2. upload_data_size > 0：把 upload_data 追加到 body，
//    把 *upload_data_size 置零（表示数据已消费），返回 MHD_YES
// 3. upload_data_size == 0：所有数据已接收，处理请求并回复

int api_handler(void *cls,
               struct MHD_Connection *connection,
               const char *url,
               const char *method,
               const char *version,
               const char *upload_data,
               size_t *upload_data_size,
               void **con_cls) {

    (void)cls; (void)version;

    // ========== 第一次调用：初始化 ==========
    if (*con_cls == NULL) {
        struct PostData *pd = (struct PostData*)calloc(1, sizeof(struct PostData));
        if (!pd) return MHD_NO;
        pd->body_capacity = 4096;
        pd->body = (char*)malloc(pd->body_capacity);
        if (!pd->body) {
            free(pd);
            return MHD_NO;
        }
        pd->body[0] = '\0';
        pd->body_size = 0;
        *con_cls = pd;
        return MHD_YES;
    }

    struct PostData *pd = (struct PostData*)*con_cls;

    // ========== POST 请求 ==========
    if (strcmp(method, "POST") == 0) {
        // 还有数据需要读取
        if (*upload_data_size > 0) {
            // 扩容（如果需要）
            size_t needed = pd->body_size + *upload_data_size + 1;
            if (needed > pd->body_capacity) {
                size_t new_cap = pd->body_capacity * 2;
                if (new_cap < needed) new_cap = needed;
                char *new_body = (char*)realloc(pd->body, new_cap);
                if (!new_body) return MHD_NO;
                pd->body = new_body;
                pd->body_capacity = new_cap;
            }
            // 把上传数据追加到 body
            memcpy(pd->body + pd->body_size, upload_data, *upload_data_size);
            pd->body_size += *upload_data_size;
            pd->body[pd->body_size] = '\0';

            // 关键：把 upload_data_size 置零，告诉 MHD 数据已消费
            *upload_data_size = 0;
            return MHD_YES;
        }

        // upload_data_size == 0：所有 POST 数据已接收，处理请求
        char *body = pd->body;
        char *response_json = NULL;

        if (strcmp(url, "/api/user/register") == 0) {
            response_json = auth_register(body);
        }
        else if (strcmp(url, "/api/login/confirm") == 0) {
            response_json = auth_confirm_login(body);
        }
        else if (strcmp(url, "/api/favorites/sync") == 0) {
            response_json = favorite_sync(body);
        }
        else if (strcmp(url, "/api/favorites/add") == 0) {
            // 单个添加喜欢
            response_json = favorite_add(body);
        }
        else if (strcmp(url, "/api/user/avatar") == 0) {
            // 头像上传
            response_json = handle_avatar_upload(body);
        }
        else if (strcmp(url, "/api/downloads/add") == 0) {
            // 添加下载记录
            response_json = download_add(body);
        }
        else if (strcmp(url, "/api/downloads/sync") == 0) {
            // 批量同步下载记录
            response_json = download_sync(body);
        }
        else {
            response_json = utils_json_error(-1, "未知接口");
        }

        // 清理
        free(pd->body);
        free(pd);
        *con_cls = NULL;

        if (response_json) {
            int ret = api_send_json(connection, 200, response_json);
            free(response_json);
            return ret;
        }
        return MHD_NO;
    }

    // ========== GET 请求 ==========
    if (strcmp(method, "GET") == 0) {
        char *response_json = NULL;

        // 路由：请求登录token
        if (strcmp(url, "/api/login/token") == 0) {
            response_json = auth_request_token(G_SERVER_BASE_URL);
        }
        // 路由：检查登录状态
        else if (strcmp(url, "/api/login/check") == 0) {
            // 直接用 MHD_lookup_connection_value 获取 token 参数
            const char *token = MHD_lookup_connection_value(
                connection, MHD_GET_ARGUMENT_KIND, "token");
            response_json = auth_check_login(token);
        }
        // 路由：获取喜欢音乐列表
        else if (strcmp(url, "/api/favorites") == 0) {
            // 直接获取 user_id 参数
            const char *user_id = MHD_lookup_connection_value(
                connection, MHD_GET_ARGUMENT_KIND, "user_id");
            response_json = favorite_get_list(user_id);
        }
        // 路由：获取下载记录列表
        else if (strcmp(url, "/api/downloads") == 0) {
            // 直接获取 user_id 参数
            const char *user_id = MHD_lookup_connection_value(
                connection, MHD_GET_ARGUMENT_KIND, "user_id");
            response_json = download_get_list(user_id);
        }
        // 路由：二维码确认页面
        else if (strncmp(url, "/qr/", 4) == 0) {
            char token[65] = {0};
            if (parse_qr_token(url, token, sizeof(token)) == 0) {
                // GET 请求访问 /qr/xxx，返回HTML页面
                // 清理 con_cls
                free(pd->body);
                free(pd);
                *con_cls = NULL;
                return send_qr_html(connection, token);
            }
        }
        // 路由：头像图片访问
        else if (strncmp(url, "/avatars/", 10) == 0) {
            // 清理 con_cls
            free(pd->body);
            free(pd);
            *con_cls = NULL;
            
            // 构建本地文件路径
            char filepath[384];
            snprintf(filepath, sizeof(filepath), ".%s", url);
            return api_send_file(connection, filepath);
        }
        else {
            response_json = utils_json_error(-1, "未知接口");
        }

        // 清理
        free(pd->body);
        free(pd);
        *con_cls = NULL;

        if (response_json) {
            int ret = api_send_json(connection, 200, response_json);
            free(response_json);
            return ret;
        }
        return MHD_NO;
    }

    // ========== DELETE 请求 ==========
    if (strcmp(method, "DELETE") == 0) {
        // 直接获取 user_id 和 song_id 参数
        // 注意：客户端发送的是 id 参数，不是 song_id
        const char *user_id = MHD_lookup_connection_value(
            connection, MHD_GET_ARGUMENT_KIND, "user_id");
        const char *song_id = MHD_lookup_connection_value(
            connection, MHD_GET_ARGUMENT_KIND, "id");  // 客户端发送的是 id
        const char *type_str = MHD_lookup_connection_value(
            connection, MHD_GET_ARGUMENT_KIND, "type");
        int type = type_str ? atoi(type_str) : 1;
        
        char *response_json = NULL;
        
        // 根据 URL 路径判断是删除喜欢还是删除下载记录
        if (strstr(url, "/favorites")) {
            response_json = favorite_remove(user_id, song_id, type);
        }
        else if (strstr(url, "/downloads")) {
            response_json = download_remove(user_id, song_id, type);
        }

        // 清理
        free(pd->body);
        free(pd);
        *con_cls = NULL;

        if (response_json) {
            int ret = api_send_json(connection, 200, response_json);
            free(response_json);
            return ret;
        }
        return MHD_NO;
    }

    // 清理
    free(pd->body);
    free(pd);
    *con_cls = NULL;

    return MHD_NO;
}
