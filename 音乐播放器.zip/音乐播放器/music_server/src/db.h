#ifndef DB_H
#define DB_H

#include <mysql/mysql.h>
#include "cJSON.h"

// ========== 数据库连接 ==========

// 初始化数据库连接池（这里简化为单个连接）
// 返回0表示成功
int db_init(const char *host, const char *user, const char *password, const char *db_name, unsigned int port);

// 关闭数据库连接
void db_close(void);

// 获取一个数据库连接（线程安全：每次调用返回独立连接）
// 使用完毕后需调用 mysql_close() 关闭
MYSQL* db_get_connection(void);

// ========== 用户相关 ==========

// 用户注册，返回用户UUID字符串（需调用者free），失败返回NULL
char* db_user_register(const char *username, const char *password_hash);

// 根据用户名查询用户，结果填入参数，返回0表示成功
// user_id需预分配37字节，password_hash需预分配65字节
int db_user_get_by_username(const char *username, char *user_id, char *password_hash);

// 根据用户ID查询用户，返回cJSON对象（包含user_id, username, avatar_url）
// 调用者需cJSON_Delete释放
cJSON* db_user_get_by_id(const char *user_id);

// 更新用户头像URL，返回0表示成功
int db_user_update_avatar(const char *user_id, const char *avatar_url);

// ========== Token相关 ==========

// 创建登录token，返回token字符串（需调用者free），失败返回NULL
char* db_token_create(const char *token, int ttl_seconds);

// 确认登录：根据token查询并设置用户ID，返回0表示成功
int db_token_confirm(const char *token, const char *user_id);

// 检查token状态，返回状态：0=待确认，1=已确认，2=已过期，-1=不存在
// 如果已确认，user_id_buf会填入用户ID（需预分配37字节）
int db_token_check(const char *token, char *user_id_buf);

// 清理过期token（可选，定期调用）
int db_token_cleanup(void);

// ========== 喜欢音乐相关 ==========

// 添加或更新喜欢音乐（INSERT IGNORE，已存在则跳过）
// 返回0表示成功
int db_favorite_add(const char *user_id, const char *song_id, const char *song_name,
                    const char *artist, const char *album, const char *duration,
                    int type, const char *pic_url);

// 删除喜欢音乐，返回0表示成功
int db_favorite_remove(const char *user_id, const char *song_id, int type);

// 查询用户的喜欢音乐列表，返回cJSON数组
// 调用者需cJSON_Delete释放
cJSON* db_favorite_get_list(const char *user_id);

// 批量同步喜欢音乐（先删除该用户所有记录，再批量插入）
// 返回成功同步的数量，-1表示失败
int db_favorite_sync(const char *user_id, cJSON *songs_array);

// ========== 下载记录相关 ==========

// 添加或更新下载记录（INSERT ON DUPLICATE KEY UPDATE）
// 返回0表示成功
int db_download_add(const char *user_id, const char *song_id, const char *song_name,
                     const char *artist, const char *album, const char *duration,
                     int type, const char *pic_url, const char *save_path,
                     long long file_size, const char *finish_time);

// 删除下载记录，返回0表示成功
int db_download_remove(const char *user_id, const char *song_id, int type);

// 查询用户的下载记录列表，返回cJSON数组
// 调用者需cJSON_Delete释放
cJSON* db_download_get_list(const char *user_id);

// 批量同步下载记录（先删除该用户所有记录，再批量插入）
// 返回成功同步的数量，-1表示失败
int db_download_sync(const char *user_id, cJSON *downloads_array);

#endif // DB_H
