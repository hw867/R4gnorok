#include "download.h"
#include "db.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 添加下载记录
char* download_add(const char *body) {
    if (!body) {
        return utils_json_error(-1, "请求体为空");
    }
    
    cJSON *json = cJSON_Parse(body);
    if (!json) {
        return utils_json_error(-1, "JSON解析失败");
    }
    
    cJSON *user_id_obj = cJSON_GetObjectItem(json, "user_id");
    cJSON *song_id_obj = cJSON_GetObjectItem(json, "song_id");
    cJSON *song_name_obj = cJSON_GetObjectItem(json, "song_name");
    
    if (!user_id_obj || !song_id_obj || !song_name_obj ||
        !user_id_obj->valuestring || !song_id_obj->valuestring || !song_name_obj->valuestring) {
        cJSON_Delete(json);
        return utils_json_error(-1, "缺少必要参数");
    }
    
    cJSON *artist_obj = cJSON_GetObjectItem(json, "artist");
    cJSON *album_obj = cJSON_GetObjectItem(json, "album");
    cJSON *duration_obj = cJSON_GetObjectItem(json, "duration");
    cJSON *type_obj = cJSON_GetObjectItem(json, "type");
    cJSON *pic_url_obj = cJSON_GetObjectItem(json, "pic_url");
    cJSON *save_path_obj = cJSON_GetObjectItem(json, "save_path");
    cJSON *file_size_obj = cJSON_GetObjectItem(json, "file_size");
    cJSON *finish_time_obj = cJSON_GetObjectItem(json, "finish_time");
    
    int ret = db_download_add(
        user_id_obj->valuestring,
        song_id_obj->valuestring,
        song_name_obj->valuestring,
        artist_obj ? artist_obj->valuestring : "",
        album_obj ? album_obj->valuestring : "",
        duration_obj ? duration_obj->valuestring : "",
        type_obj ? type_obj->valueint : 1,
        pic_url_obj ? pic_url_obj->valuestring : "",
        save_path_obj ? save_path_obj->valuestring : "",
        file_size_obj ? (long long)file_size_obj->valuedouble : 0,
        finish_time_obj ? finish_time_obj->valuestring : ""
    );
    
    cJSON_Delete(json);
    
    if (ret != 0) {
        return utils_json_error(-1, "添加下载记录失败");
    }
    
    return utils_json_success("{\"message\":\"添加成功\"}");
}

// 删除下载记录（直接接收参数）
char* download_remove(const char *user_id, const char *song_id, int type) {
    if (!user_id || !song_id) {
        return utils_json_error(-1, "缺少user_id或song_id");
    }
    
    int ret = db_download_remove(user_id, song_id, type);
    
    if (ret != 0) {
        return utils_json_error(-1, "删除下载记录失败");
    }
    
    return utils_json_success("{\"message\":\"删除成功\"}");
}

// 获取下载记录列表（直接接收user_id）
char* download_get_list(const char *user_id) {
    if (!user_id) {
        return utils_json_error(-1, "缺少user_id");
    }
    
    cJSON *downloads_array = db_download_get_list(user_id);
    
    if (!downloads_array) {
        return utils_json_error(-1, "获取列表失败");
    }
    
    char *array_str = cJSON_PrintUnformatted(downloads_array);
    cJSON_Delete(downloads_array);
    
    char *data = (char*)malloc(strlen(array_str) + 16);
    if (data) {
        sprintf(data, "{\"downloads\":%s}", array_str);
    }
    free(array_str);
    
    char *response = utils_json_success(data);
    free(data);
    return response;
}

// 同步下载记录（批量）
char* download_sync(const char *body) {
    if (!body) {
        return utils_json_error(-1, "请求体为空");
    }
    
    cJSON *json = cJSON_Parse(body);
    if (!json) {
        return utils_json_error(-1, "JSON解析失败");
    }
    
    cJSON *user_id_obj = cJSON_GetObjectItem(json, "user_id");
    cJSON *downloads_obj = cJSON_GetObjectItem(json, "downloads");
    
    if (!user_id_obj || !user_id_obj->valuestring || !downloads_obj) {
        cJSON_Delete(json);
        return utils_json_error(-1, "缺少user_id或downloads");
    }
    
    int count = db_download_sync(user_id_obj->valuestring, downloads_obj);
    cJSON_Delete(json);
    
    if (count < 0) {
        return utils_json_error(-1, "同步失败");
    }
    
    char data[64];
    snprintf(data, sizeof(data), "{\"count\":%d}", count);
    return utils_json_success(data);
}
