#include "auth.h"
#include "db.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 处理用户注册请求
char* auth_register(const char *body) {
    if (!body) {
        return utils_json_error(-1, "请求体为空");
    }
    
    cJSON *json = cJSON_Parse(body);
    if (!json) {
        return utils_json_error(-1, "JSON解析失败");
    }
    
    cJSON *username_obj = cJSON_GetObjectItem(json, "username");
    cJSON *password_obj = cJSON_GetObjectItem(json, "password");
    
    if (!username_obj || !password_obj ||
        !username_obj->valuestring || !password_obj->valuestring) {
        cJSON_Delete(json);
        return utils_json_error(-1, "缺少用户名或密码");
    }
    
    char *username = username_obj->valuestring;
    char *password = password_obj->valuestring;
    
    // 密码长度检查
    if (strlen(password) < 6) {
        cJSON_Delete(json);
        return utils_json_error(-1, "密码长度至少6位");
    }
    
    // SHA256加密密码
    char *password_hash = utils_sha256(password);
    if (!password_hash) {
        cJSON_Delete(json);
        return utils_json_error(-1, "密码加密失败");
    }
    
    // 注册用户
    char *user_id = db_user_register(username, password_hash);
    free(password_hash);
    cJSON_Delete(json);
    
    if (!user_id) {
        return utils_json_error(-1, "注册失败，用户名可能已存在");
    }
    
    // 返回成功响应
    char data[128];
    snprintf(data, sizeof(data), "{\"user_id\":\"%s\",\"username\":\"%s\"}", user_id, username);
    free(user_id);
    
    return utils_json_success(data);
}

// 请求登录token
char* auth_request_token(const char *server_base_url) {
    // 生成随机token
    char *token = utils_generate_token(16);  // 32位十六进制字符串
    if (!token) {
        return utils_json_error(-1, "生成token失败");
    }
    
    // 存入数据库
    if (!db_token_create(token, 600)) {  // 10分钟过期
        free(token);
        return utils_json_error(-1, "保存token失败");
    }
    
    // 构建响应
    const char *base = server_base_url ? server_base_url : "http://localhost:8080";
    
    char *data = (char*)malloc(strlen(base) + strlen(token) + 64);
    if (!data) {
        free(token);
        return utils_json_error(-1, "内存分配失败");
    }
    
    snprintf(data, strlen(base) + strlen(token) + 64,
             "{\"token\":\"%s\",\"qr_url\":\"%s/qr/%s\"}",
             token, base, token);
    
    free(token);
    char *response = utils_json_success(data);
    free(data);
    return response;
}

// 确认登录（手机端扫码后点击确认）
char* auth_confirm_login(const char *body) {
    if (!body) {
        return utils_json_error(-1, "请求体为空");
    }
    
    cJSON *json = cJSON_Parse(body);
    if (!json) {
        return utils_json_error(-1, "JSON解析失败");
    }
    
    cJSON *token_obj = cJSON_GetObjectItem(json, "token");
    cJSON *username_obj = cJSON_GetObjectItem(json, "username");
    cJSON *password_obj = cJSON_GetObjectItem(json, "password");
    
    if (!token_obj || !username_obj || !password_obj ||
        !token_obj->valuestring || !username_obj->valuestring || !password_obj->valuestring) {
        cJSON_Delete(json);
        return utils_json_error(-1, "缺少token、用户名或密码");
    }
    
    char *token = token_obj->valuestring;
    char *username = username_obj->valuestring;
    char *password = password_obj->valuestring;
    
    // 验证用户名和密码
    char user_id[37] = {0};
    char password_hash[65] = {0};
    
    if (db_user_get_by_username(username, user_id, password_hash) != 0) {
        cJSON_Delete(json);
        return utils_json_error(-1, "用户不存在");
    }
    
    // 验证密码
    char *input_hash = utils_sha256(password);
    if (!input_hash || strcmp(input_hash, password_hash) != 0) {
        free(input_hash);
        cJSON_Delete(json);
        return utils_json_error(-1, "密码错误");
    }
    free(input_hash);
    
    // 确认token
    if (db_token_confirm(token, user_id) != 0) {
        cJSON_Delete(json);
        return utils_json_error(-1, "确认登录失败，token可能已过期");
    }
    
    cJSON_Delete(json);
    return utils_json_success("{\"message\":\"登录成功\"}");
}

// 检查登录状态（客户端轮询）
char* auth_check_login(const char *token) {
    if (!token) {
        return utils_json_error(-1, "token为空");
    }
    
    char user_id[37] = {0};
    int status = db_token_check(token, user_id);
    
    if (status == -1) {
        return utils_json_error(-1, "token不存在或已过期");
    }
    
    if (status == 0) {
        // 待确认
        return utils_json_success("{\"status\":0}");
    }
    
    if (status == 1) {
        // 已确认，返回用户信息
        cJSON *user_json = db_user_get_by_id(user_id);
        if (!user_json) {
            return utils_json_error(-1, "获取用户信息失败");
        }
        
        char *user_str = cJSON_PrintUnformatted(user_json);
        cJSON_Delete(user_json);
        
        char *data = (char*)malloc(strlen(user_str) + 32);
        if (data) {
            sprintf(data, "{\"status\":1,\"user\":%s}", user_str);
        }
        free(user_str);
        
        char *response = utils_json_success(data);
        free(data);
        return response;
    }
    
    return utils_json_error(-1, "未知状态");
}
