-- ========== 音乐播放器服务器数据库初始化脚本 ==========
-- 执行方式: mysql -u root -p < init_db.sql

-- 创建数据库
CREATE DATABASE IF NOT EXISTS music_server
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE music_server;

-- 临时关闭外键检查，避免删除表时因外键依赖报错
SET FOREIGN_KEY_CHECKS = 0;

-- ========== 用户表 ==========
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    user_id      VARCHAR(36) PRIMARY KEY,
    username     VARCHAR(50) UNIQUE NOT NULL,
    password     VARCHAR(64) NOT NULL COMMENT 'SHA256哈希（64位十六进制）',
    avatar_url   VARCHAR(255) DEFAULT '',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 喜欢的音乐表 ==========
DROP TABLE IF EXISTS favorites;
CREATE TABLE favorites (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     VARCHAR(36) NOT NULL,
    song_id     VARCHAR(100) NOT NULL COMMENT '网易云歌曲ID或本地完整路径',
    song_name   VARCHAR(255) NOT NULL,
    artist      VARCHAR(100) DEFAULT '',
    album       VARCHAR(100) DEFAULT '',
    duration    VARCHAR(10) DEFAULT '',
    type        INT DEFAULT 1 COMMENT '0:本地 1:在线',
    pic_url     VARCHAR(500) DEFAULT '',
    added_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_song (user_id, song_id, type),
    INDEX idx_user_id (user_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 登录token表 ==========
DROP TABLE IF EXISTS login_tokens;
CREATE TABLE login_tokens (
    token       VARCHAR(64) PRIMARY KEY,
    user_id     VARCHAR(36) DEFAULT NULL,
    status      INT DEFAULT 0 COMMENT '0:待扫码 1:已确认 2:已过期',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    confirmed_at TIMESTAMP NULL,
    INDEX idx_status (status),
    INDEX idx_created (created_at),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 下载记录表 ==========
DROP TABLE IF EXISTS downloads;
CREATE TABLE downloads (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     VARCHAR(36) NOT NULL,
    song_id     VARCHAR(100) NOT NULL COMMENT '网易云歌曲ID或本地完整路径',
    song_name   VARCHAR(255) NOT NULL,
    artist      VARCHAR(100) DEFAULT '',
    album       VARCHAR(100) DEFAULT '',
    duration    VARCHAR(10) DEFAULT '',
    type        INT DEFAULT 1 COMMENT '0:本地 1:在线',
    pic_url     VARCHAR(500) DEFAULT '',
    save_path   TEXT COMMENT '本地保存路径',
    file_size   BIGINT DEFAULT 0 COMMENT '文件大小(字节)',
    finish_time DATETIME COMMENT '下载完成时间',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_song (user_id, song_id, type),
    INDEX idx_user_id (user_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========== 测试数据（可选） ==========
-- 插入测试用户（密码: 123456，SHA256哈希）
-- 可以使用命令生成: echo -n "123456" | openssl dgst -sha256

-- 查看表结构
SHOW TABLES;
DESCRIBE users;
DESCRIBE favorites;
DESCRIBE login_tokens;

-- 恢复外键检查
SET FOREIGN_KEY_CHECKS = 1;

-- 完成提示
SELECT '数据库初始化完成！' AS message;
