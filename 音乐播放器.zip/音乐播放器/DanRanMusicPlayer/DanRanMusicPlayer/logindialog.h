#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>

class QLabel;
class QPushButton;

class LoginDialog : public QDialog
{
    Q_OBJECT
public:
    explicit LoginDialog(QWidget *parent = nullptr);
    ~LoginDialog();

signals:
    void loginSuccess();

private slots:
    void onSimulateLoginClicked();

private:
    QLabel *m_qrLabel;
    QPushButton *m_simulateBtn;
    QPushButton *m_cancelBtn;
};

#endif // LOGINDIALOG_H
