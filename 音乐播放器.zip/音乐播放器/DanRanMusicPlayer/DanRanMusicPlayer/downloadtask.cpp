#include "downloadtask.h"
#include <QUuid>
#include <QDir>
#include <QCoreApplication>
#include <QRegularExpression>
#include <QDebug>
#include <QNetworkRequest>

DownloadTask::DownloadTask(QObject *parent)
    : QObject(parent)
    , m_networkManager(new QNetworkAccessManager(this))
    , m_musicReply(nullptr)
    , m_picReply(nullptr)
    , m_musicFile(nullptr)
    , m_isCancelled(false)
{
    // 生成唯一任务ID
    m_info.taskId = QUuid::createUuid().toString(QUuid::WithoutBraces);
    m_info.status = DownloadWaiting;
    m_info.downloadedBytes = 0;
    m_info.totalBytes = 0;
}

DownloadTask::~DownloadTask()
{
    // 【修复】已完成的任务不删除文件，只取消未完成的下载
    if (m_info.status == DownloadCompleted) {
        // 已完成，只清理网络资源，不删除文件
        if (m_musicReply) {
            m_musicReply->abort();
            m_musicReply->deleteLater();
            m_musicReply = nullptr;
        }
        if (m_musicFile) {
            m_musicFile->close();
            m_musicFile->deleteLater();
            m_musicFile = nullptr;
        }
    } else {
        // 未完成，取消下载并删除临时文件
        cancelDownload();
    }
}

void DownloadTask::setDownloadInfo(const DownloadInfo &info)
{
    m_info = info;
    if (m_info.taskId.isEmpty()) {
        m_info.taskId = QUuid::createUuid().toString(QUuid::WithoutBraces);
    }
    m_info.addTime = QDateTime::currentDateTime();
}

DownloadInfo DownloadTask::getDownloadInfo() const
{
    return m_info;
}

void DownloadTask::setStatus(DownloadStatus status)
{
    m_info.status = status;
}

void DownloadTask::startDownload()
{
    if (m_info.status == DownloadDownloading) {
        qDebug() << "下载任务已在下载中，跳过:" << m_info.songName;
        return;
    }

    m_isCancelled = false;
    m_info.status = DownloadDownloading;
    qDebug() << "开始下载任务:" << m_info.songName << "URL:" << m_info.musicUrl;
    emit sig_statusChanged(m_info.taskId, DownloadDownloading);

    // 先下载音乐文件
    downloadMusic();
}

void DownloadTask::pauseDownload()
{
    if (m_info.status != DownloadDownloading) {
        return;
    }

    m_info.status = DownloadPaused;
    if (m_musicReply) {
        m_musicReply->abort();
    }
    emit sig_statusChanged(m_info.taskId, DownloadPaused);
}

void DownloadTask::resumeDownload()
{
    if (m_info.status != DownloadPaused) {
        return;
    }

    startDownload();
}

void DownloadTask::cancelDownload()
{
    m_isCancelled = true;

    if (m_musicReply) {
        m_musicReply->abort();
        m_musicReply->deleteLater();
        m_musicReply = nullptr;
    }

    if (m_picReply) {
        m_picReply->abort();
        m_picReply->deleteLater();
        m_picReply = nullptr;
    }

    if (m_musicFile) {
        m_musicFile->close();
        m_musicFile->deleteLater();
        m_musicFile = nullptr;
    }

    // 删除已下载的临时文件
    if (!m_info.savePath.isEmpty()) {
        QFile::remove(m_info.savePath);
    }
    if (!m_info.lyricPath.isEmpty()) {
        QFile::remove(m_info.lyricPath);
    }
    // 删除已下载的封面文件
    if (!m_coverSavePath.isEmpty()) {
        QFile::remove(m_coverSavePath);
    }
}

void DownloadTask::downloadMusic()
{
    if (m_info.musicUrl.isEmpty()) {
        // 如果没有音乐URL，直接完成（不应该发生）
        m_info.status = DownloadCompleted;
        m_info.finishTime = QDateTime::currentDateTime();
        emit sig_statusChanged(m_info.taskId, DownloadCompleted);
        emit sig_downloadFinished(m_info.taskId, false, "音乐URL为空");
        return;
    }

    // 确保保存目录存在
    QFileInfo fileInfo(m_info.savePath);
    QDir dir = fileInfo.dir();
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    // 创建文件
    m_musicFile = new QFile(m_info.savePath, this);
    if (!m_musicFile->open(QIODevice::WriteOnly)) {
        m_info.status = DownloadFailed;
        emit sig_statusChanged(m_info.taskId, DownloadFailed);
        emit sig_downloadFinished(m_info.taskId, false, "无法创建文件");
        return;
    }

    // 开始下载
    QNetworkRequest request;
    request.setUrl(QUrl(m_info.musicUrl));
    request.setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0");

    m_musicReply = m_networkManager->get(request);
    // 使用 Qt::QueuedConnection 确保在 DownloadTask 所在线程（主线程）中执行槽函数
    connect(m_musicReply, &QNetworkReply::finished, this, &DownloadTask::onMusicDownloadFinished, Qt::QueuedConnection);
    connect(m_musicReply, &QNetworkReply::downloadProgress, this, &DownloadTask::onMusicDownloadProgress, Qt::QueuedConnection);
}

void DownloadTask::downloadLyric()
{
    if (m_info.lyricUrl.isEmpty()) {
        // 没有歌词URL，直接完成
        m_info.status = DownloadCompleted;
        m_info.finishTime = QDateTime::currentDateTime();
        emit sig_statusChanged(m_info.taskId, DownloadCompleted);
        emit sig_downloadCompleted(m_info);
        emit sig_downloadFinished(m_info.taskId, true, "");
        return;
    }

    // 确保歌词目录存在
    QFileInfo fileInfo(m_info.lyricPath);
    QDir dir = fileInfo.dir();
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    QNetworkRequest request;
    request.setUrl(QUrl(m_info.lyricUrl));
    request.setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0");

    QNetworkReply *reply = m_networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        if (reply->error() == QNetworkReply::NoError) {
            QFile lyricFile(m_info.lyricPath);
            if (lyricFile.open(QIODevice::WriteOnly)) {
                lyricFile.write(reply->readAll());
                lyricFile.close();
            }
        }
        reply->deleteLater();
    });
}

// 新增：使用回调方式的歌词下载，确保在歌词下载完成后才发出完成信号
void DownloadTask::downloadLyricWithCallback()
{
    qDebug() << "downloadLyricWithCallback: 开始下载歌词";
    
    if (m_info.lyricUrl.isEmpty()) {
        qDebug() << "downloadLyricWithCallback: 歌词URL为空，直接完成";
        m_info.status = DownloadCompleted;
        m_info.finishTime = QDateTime::currentDateTime();
        emit sig_statusChanged(m_info.taskId, DownloadCompleted);
        emit sig_downloadCompleted(m_info);
        emit sig_downloadFinished(m_info.taskId, true, "");
        return;
    }

    // 确保歌词目录存在
    QFileInfo fileInfo(m_info.lyricPath);
    QDir dir = fileInfo.dir();
    if (!dir.exists()) {
        dir.mkpath(".");
    }

    qDebug() << "downloadLyricWithCallback: 歌词保存路径:" << m_info.lyricPath;

    QNetworkRequest request;
    request.setUrl(QUrl(m_info.lyricUrl));
    request.setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0");

    QNetworkReply *reply = m_networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, [this, reply]() {
        qDebug() << "downloadLyricWithCallback: 歌词网络请求完成";
        
        if (m_isCancelled) {
            qDebug() << "downloadLyricWithCallback: 任务已取消";
            reply->deleteLater();
            return;
        }

        if (reply->error() == QNetworkReply::NoError) {
            qDebug() << "downloadLyricWithCallback: 歌词下载成功";
            
            QFile lyricFile(m_info.lyricPath);
            if (lyricFile.open(QIODevice::WriteOnly)) {
                lyricFile.write(reply->readAll());
                lyricFile.close();
                qDebug() << "downloadLyricWithCallback: 歌词文件已写入:" << m_info.lyricPath;
            } else {
                qWarning() << "downloadLyricWithCallback: 无法打开歌词文件:" << m_info.lyricPath;
            }
            
            // 歌词下载成功后，标记任务完成
            m_info.status = DownloadCompleted;
            m_info.finishTime = QDateTime::currentDateTime();
            emit sig_statusChanged(m_info.taskId, DownloadCompleted);
            emit sig_downloadCompleted(m_info);
            emit sig_downloadFinished(m_info.taskId, true, "");
        } else {
            qWarning() << "downloadLyricWithCallback: 歌词下载失败:" << reply->errorString();
            
            // 歌词下载失败，但音乐已下载成功，仍标记为完成（只是没有歌词）
            m_info.status = DownloadCompleted;
            m_info.finishTime = QDateTime::currentDateTime();
            emit sig_statusChanged(m_info.taskId, DownloadCompleted);
            emit sig_downloadCompleted(m_info);
            emit sig_downloadFinished(m_info.taskId, true, "歌词下载失败");
        }
        
        reply->deleteLater();
    }, Qt::QueuedConnection);  // 使用队列连接确保在主线程执行
}

void DownloadTask::onMusicDownloadFinished()
{
    qDebug() << "onMusicDownloadFinished 被调用";
    
    if (!m_musicReply) {
        qDebug() << "onMusicDownloadFinished: m_musicReply 为空";
        return;
    }

    QNetworkReply *reply = m_musicReply;
    m_musicReply = nullptr;

    if (m_isCancelled) {
        qDebug() << "onMusicDownloadFinished: 任务已取消";
        reply->deleteLater();
        return;
    }

    qDebug() << "onMusicDownloadFinished: 网络错误:" << (reply->error() != QNetworkReply::NoError);

    if (reply->error() == QNetworkReply::NoError) {
        // 下载成功
        QByteArray data = reply->readAll();
        qDebug() << "onMusicDownloadFinished: 下载成功，数据大小:" << data.size() << "字节";
        
        if (m_musicFile && m_musicFile->isOpen()) {
            m_musicFile->write(data);
            m_musicFile->close();
            qDebug() << "onMusicDownloadFinished: 文件已写入:" << m_info.savePath;
        } else {
            qWarning() << "onMusicDownloadFinished: 文件未打开或不存在!";
            if (!m_info.savePath.isEmpty()) {
                qWarning() << "保存路径为空！这可能导致问题";
            }
        }
        
        if (m_musicFile) {
            m_musicFile->deleteLater();
            m_musicFile = nullptr;
        }
        
        reply->deleteLater();
        
        // 【新增】音乐下载成功后，发起封面下载（与歌词下载并行，不影响任务完成状态）
        if (!m_info.picUrl.isEmpty()) {
            downloadCover();
        }
        
        // 根据是否有歌词URL决定下一步
        if (m_info.lyricUrl.isEmpty()) {
            // 没有歌词URL，直接标记完成（封面下载在后台进行，不影响任务状态）
            qDebug() << "onMusicDownloadFinished: 无歌词URL，直接完成（封面在后台下载）";
            m_info.status = DownloadCompleted;
            m_info.finishTime = QDateTime::currentDateTime();
            emit sig_statusChanged(m_info.taskId, DownloadCompleted);
            emit sig_downloadCompleted(m_info);
            emit sig_downloadFinished(m_info.taskId, true, "");
        } else {
            // 有歌词URL，先下载歌词（使用回调方式）
            qDebug() << "onMusicDownloadFinished: 有歌词URL，开始下载歌词";
            downloadLyricWithCallback();
        }
    } else {
        // 下载失败
        qDebug() << "onMusicDownloadFailed: 错误信息:" << reply->errorString();
        
        if (m_musicFile) {
            m_musicFile->close();
            m_musicFile->deleteLater();
            m_musicFile = nullptr;
        }

        QString errorMsg = reply->errorString();
        reply->deleteLater();

        m_info.status = DownloadFailed;
        emit sig_statusChanged(m_info.taskId, DownloadFailed);
        emit sig_downloadFinished(m_info.taskId, false, errorMsg);
    }
}

void DownloadTask::onMusicDownloadProgress(qint64 bytesReceived, qint64 bytesTotal)
{
    if (m_isCancelled) return;

    m_info.downloadedBytes = bytesReceived;
    m_info.totalBytes = bytesTotal;
    emit sig_progressUpdated(m_info.taskId, bytesReceived, bytesTotal);
}

void DownloadTask::onLyricDownloadFinished()
{
    // 歌词下载完成后的处理（可选）
    qDebug() << "歌词下载完成:" << m_info.lyricPath;
}

// ================== 封面下载 ==================
void DownloadTask::downloadCover()
{
    if (m_info.picUrl.isEmpty()) {
        m_picReply = nullptr;
        return;
    }

    // 确保 img 目录存在（debug/img/）
    QString imgDir = QCoreApplication::applicationDirPath() + "/img";
    QDir dir;
    if (!dir.exists(imgDir)) {
        dir.mkpath(imgDir);
        qDebug() << "downloadCover: 创建img目录" << imgDir;
    }

    // 从 picUrl 中提取扩展名，默认 jpg
    QString ext = "jpg";
    QString urlPath = QUrl(m_info.picUrl).path();
    if (urlPath.contains(".")) {
        ext = urlPath.mid(urlPath.lastIndexOf(".") + 1).toLower();
        if (ext != "png" && ext != "jpg" && ext != "jpeg" && ext != "bmp") {
            ext = "jpg";
        }
    }

    // 安全化处理歌曲名，作为文件名
    QString safeName = m_info.songName;
    safeName.replace(QRegularExpression("[\\\\/:*?\"<>|]"), "_");

    // 封面保存路径：debug/img/歌曲名.jpg
    QString coverSavePath = imgDir + "/" + safeName + "." + ext;
    m_coverSavePath = coverSavePath;

    qDebug() << "downloadCover: 开始下载封面" << m_info.picUrl << "保存到" << coverSavePath;

    QNetworkRequest request;
    request.setUrl(QUrl(m_info.picUrl));
    request.setHeader(QNetworkRequest::UserAgentHeader, "Mozilla/5.0");

    m_picReply = m_networkManager->get(request);
    connect(m_picReply, &QNetworkReply::finished, this, &DownloadTask::onPicDownloadFinished, Qt::QueuedConnection);
}

void DownloadTask::onPicDownloadFinished()
{
    if (!m_picReply) return;

    qDebug() << "onPicDownloadFinished: 封面下载完成";

    if (m_isCancelled) {
        qDebug() << "onPicDownloadFinished: 任务已取消，不保存封面";
        m_picReply->deleteLater();
        m_picReply = nullptr;
        return;
    }

    if (m_picReply->error() == QNetworkReply::NoError) {
        QByteArray imgData = m_picReply->readAll();
        QFile coverFile(m_coverSavePath);
        if (coverFile.open(QIODevice::WriteOnly)) {
            coverFile.write(imgData);
            coverFile.close();
            qDebug() << "onPicDownloadFinished: 封面已保存" << m_coverSavePath;
        } else {
            qWarning() << "onPicDownloadFinished: 无法保存封面文件" << m_coverSavePath;
        }
    } else {
        qWarning() << "onPicDownloadFinished: 封面下载失败" << m_picReply->errorString();
    }

    m_picReply->deleteLater();
    m_picReply = nullptr;
    // 封面下载不影响任务完成状态，不做任何emit
}
