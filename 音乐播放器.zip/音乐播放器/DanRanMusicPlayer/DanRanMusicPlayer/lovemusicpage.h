#ifndef LOVEMUSICPAGE_H
#define LOVEMUSICPAGE_H

#include <QObject>
#include <QTableWidget>
#include <QList>

class QNetworkAccessManager;
class QNetworkReply;
class DownloadManager;

struct FavoriteItem {
    QString id;         // 唯一标识：本地完整路径 或 在线歌曲ID
    QString name;       // 歌曲名
    QString artist;     // 歌手
    QString album;      // 专辑
    QString duration;   // 时长 mm:ss
    int type;           // 0:本地, 1:在线
    QString picUrl;     // 封面URL（在线歌曲可用）
};

class LoveMusicPage : public QObject
{
    Q_OBJECT
public:
    explicit LoveMusicPage(QWidget *container, QObject *parent = nullptr);
    ~LoveMusicPage();

    // 对外接口
    void addFavorite(const FavoriteItem &item);
    void removeFavorite(const QString &id, int type);
    bool isFavorite(const QString &id, int type) const;
    QList<FavoriteItem> getAllFavorites() const;
    bool getFavoriteInfo(const QString &id, int type, FavoriteItem &outItem) const;
    void setCurrentUserId(const QString &userId);
    void refreshTable();

    // 云端同步：登录成功后从服务器拉取喜欢列表
    void syncWithServer(const QString &userId);

    // 设置下载管理器
    void setDownloadManager(DownloadManager *manager);

signals:
    // 通知主窗口播放歌曲
    void sig_playMusic(const QString &source, const QString &songName, int type, const QString &songId);
    // 喜欢状态变化
    void sig_favoriteChanged(const QString &id, int type, bool isFav);
    // 同步状态
    void sig_syncStarted();
    void sig_syncFinished(bool success, const QString &message);

private slots:
    void onTableDoubleClicked(int row, int column);
    void onRemoveButtonClicked();
    void onDownloadButtonClicked();
    // 网络响应处理
    void onGetListReplyFinished();
    void onAddReplyFinished();
    void onGetDownloadUrlReplyFinished();

private:
    // JSON转换辅助
    QJsonObject favoriteItemToJson(const FavoriteItem &item);
    FavoriteItem jsonToFavoriteItem(const QJsonObject &obj);

    static const QString SERVER_HOST;

    QTableWidget *m_tableWidget;
    QList<FavoriteItem> m_favoriteSongs;
    QString m_currentUserId;

    QNetworkAccessManager *m_networkManager;
    bool m_syncInProgress;

    DownloadManager *m_downloadManager;
};

#endif // LOVEMUSICPAGE_H
