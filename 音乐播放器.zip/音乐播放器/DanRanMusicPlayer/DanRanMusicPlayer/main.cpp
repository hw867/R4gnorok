#include "mainwindow.h"
#include "downloadtask.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    // 注册DownloadInfo为元类型，以便在QVariant中使用
    qRegisterMetaType<DownloadInfo>("DownloadInfo");

    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
