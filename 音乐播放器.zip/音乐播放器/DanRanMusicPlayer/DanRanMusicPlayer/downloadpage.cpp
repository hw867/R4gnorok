#include "downloadpage.h"
#include <QAbstractItemView>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QPushButton>
#include <QProgressBar>
#include <QHBoxLayout>
#include <QFileInfo>
#include <QDateTime>
#include <QTimer>
#include <QDebug>
#include <QCoreApplication>
#include <QDir>

DownloadPage::DownloadPage(QWidget *container, QObject *parent)
    : QObject(parent)
    , m_container(container)
    , m_downloadingTable(nullptr)
    , m_completedTable(nullptr)
    , m_downloadManager(nullptr)
{
    if (!container) {
        qWarning() << "DownloadPage: container is null";
        return;
    }

    // UI文件中：正在下载是 tableWidget_2，下载完成是 tableWidget
    m_downloadingTable = container->findChild<QTableWidget*>("tableWidget_2");
    m_completedTable = container->findChild<QTableWidget*>("tableWidget");

    if (!m_downloadingTable) {
        qWarning() << "DownloadPage: 未找到 tableWidget_2";
    }
    if (!m_completedTable) {
        qWarning() << "DownloadPage: 未找到 tableWidget";
    }

    // 【只加这两行】整行选择 + 禁止编辑（不改动UI列结构）
    if (m_downloadingTable) {
        m_downloadingTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        m_downloadingTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        connect(m_downloadingTable, &QTableWidget::cellDoubleClicked,
                this, &DownloadPage::onDownloadingDoubleClicked);
    }
    if (m_completedTable) {
        m_completedTable->setSelectionBehavior(QAbstractItemView::SelectRows);
        m_completedTable->setSelectionMode(QAbstractItemView::SingleSelection);
        m_completedTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
        connect(m_completedTable, &QTableWidget::cellDoubleClicked,
                this, &DownloadPage::onCompletedDoubleClicked);
    }

    QPushButton *btnAllDownload = container->findChild<QPushButton*>("pb_allDownLoad");
    QPushButton *btnAllPause = container->findChild<QPushButton*>("pb_allPasue");
    QPushButton *btnAllClean = container->findChild<QPushButton*>("pb_allClean");

    if (btnAllDownload) {
        connect(btnAllDownload, &QPushButton::clicked, this, [this]() {
            if (m_downloadManager) {
                QList<DownloadInfo> tasks = m_downloadManager->getDownloadingTasks();
                for (const DownloadInfo &info : tasks) {
                    if (info.status == DownloadPaused) {
                        m_downloadManager->resumeTask(info.taskId);
                    }
                }
            }
        });
    }
    if (btnAllPause) {
        connect(btnAllPause, &QPushButton::clicked, this, [this]() {
            if (m_downloadManager) {
                QList<DownloadInfo> tasks = m_downloadManager->getDownloadingTasks();
                for (const DownloadInfo &info : tasks) {
                    if (info.status == DownloadDownloading) {
                        m_downloadManager->pauseTask(info.taskId);
                    }
                }
            }
        });
    }
    if (btnAllClean) {
        connect(btnAllClean, &QPushButton::clicked, this, &DownloadPage::onClearButtonClicked);
    }
}

DownloadPage::~DownloadPage()
{
}

void DownloadPage::setDownloadManager(DownloadManager *manager)
{
    if (!m_downloadManager.isNull()) {
        disconnect(m_downloadManager, nullptr, this, nullptr);
    }
    m_downloadManager = manager;

    if (!m_downloadManager.isNull()) {
        connect(m_downloadManager, &DownloadManager::sig_taskAdded,
                this, &DownloadPage::onTaskAdded, Qt::QueuedConnection);
        connect(m_downloadManager, &DownloadManager::sig_progressUpdated,
                this, &DownloadPage::onProgressUpdated, Qt::QueuedConnection);
        connect(m_downloadManager, &DownloadManager::sig_statusChanged,
                this, &DownloadPage::onStatusChanged, Qt::QueuedConnection);
        connect(m_downloadManager, &DownloadManager::sig_taskCompleted,
                this, &DownloadPage::onTaskCompleted, Qt::QueuedConnection);
        connect(m_downloadManager, &DownloadManager::sig_syncDownloadsFinished,
                this, &DownloadPage::onSyncDownloadsFinished, Qt::QueuedConnection);

        refreshDownloadingTable();
        // 【修复】延迟刷新已完成表格，确保UI完全初始化
        QTimer::singleShot(0, this, [this]() { refreshCompletedTable(); });
    }
}

void DownloadPage::refreshDownloadingTable()
{
    qDebug() << "refreshDownloadingTable 被调用";

    if (m_downloadingTable.isNull() || m_downloadManager.isNull()) return;

    m_downloadingTable->setRowCount(0);
    QList<DownloadInfo> tasks = m_downloadManager->getDownloadingTasks();
    qDebug() << "正在下载的任务数量:" << tasks.size();

    for (int i = 0; i < tasks.size(); ++i) {
        const DownloadInfo &info = tasks[i];
        m_downloadingTable->insertRow(i);

        // 第0列：歌名
        QTableWidgetItem *nameItem = new QTableWidgetItem(info.songName);
        nameItem->setData(Qt::UserRole, info.taskId);
        m_downloadingTable->setItem(i, 0, nameItem);

        // 第1列：进度条 + 完成度百分比
        QProgressBar *progressBar = new QProgressBar();
        progressBar->setMinimum(0);
        progressBar->setMaximum(100);
        progressBar->setTextVisible(true);  // 显示百分比文字
        if (info.totalBytes > 0) {
            int progress = static_cast<int>((info.downloadedBytes * 100) / info.totalBytes);
            progressBar->setValue(progress);
            progressBar->setFormat(QString("%1%").arg(progress));
        } else {
            progressBar->setValue(0);
            progressBar->setFormat("0%");
        }
        progressBar->setProperty("taskId", info.taskId);
        m_downloadingTable->setCellWidget(i, 1, progressBar);

        // 第2列：暂停 + 删除按钮
        QWidget *btnWidget = new QWidget();
        QHBoxLayout *btnLayout = new QHBoxLayout(btnWidget);
        btnLayout->setContentsMargins(4, 2, 4, 2);
        btnLayout->setSpacing(6);

        QPushButton *btnPause = new QPushButton();
        btnPause->setProperty("taskId", info.taskId);
        btnPause->setFixedSize(60, 28);

        // 根据当前状态设置按钮文字
        if (info.status == DownloadPaused) {
            btnPause->setText(QStringLiteral("继续"));
        } else if (info.status == DownloadWaiting) {
            btnPause->setText(QStringLiteral("等待"));
            btnPause->setEnabled(false);
        } else {
            btnPause->setText(QStringLiteral("暂停"));
        }
        connect(btnPause, &QPushButton::clicked, this, &DownloadPage::onPauseButtonClicked);

        QPushButton *btnDelete = new QPushButton(QStringLiteral("删除"));
        btnDelete->setProperty("taskId", info.taskId);
        btnDelete->setFixedSize(60, 28);
        connect(btnDelete, &QPushButton::clicked, this, &DownloadPage::onDeleteButtonClicked);

        btnLayout->addWidget(btnPause);
        btnLayout->addWidget(btnDelete);
        m_downloadingTable->setCellWidget(i, 2, btnWidget);
    }
    m_downloadingTable->viewport()->update();
}

void DownloadPage::refreshCompletedTable()
{
    qDebug() << "refreshCompletedTable 被调用";

    if (m_completedTable.isNull() || m_downloadManager.isNull()) return;

    m_completedTable->setRowCount(0);
    QList<DownloadInfo> tasks = m_downloadManager->getCompletedTasks();
    qDebug() << "refreshCompletedTable: 已完成任务数量:" << tasks.size()
             << "列数:" << m_completedTable->columnCount();

    for (int i = 0; i < tasks.size(); ++i) {
        const DownloadInfo &info = tasks[i];
        qDebug() << "添加任务" << i << info.songName << "状态:" << info.status;

        m_completedTable->insertRow(i);
        QTableWidgetItem *nameItem = new QTableWidgetItem(info.songName);
        nameItem->setData(Qt::UserRole, info.taskId);
        m_completedTable->setItem(i, 0, nameItem);
        m_completedTable->setItem(i, 1, new QTableWidgetItem(info.artist));
        m_completedTable->setItem(i, 2, new QTableWidgetItem(info.album));

        qint64 fileSize = 0;
        if (!info.savePath.isEmpty()) {
            QFileInfo fi(info.savePath);
            fileSize = fi.exists() ? fi.size() : info.totalBytes;
        } else {
            fileSize = info.totalBytes;
        }
        qDebug() << "文件大小:" << info.songName << "savePath:" << info.savePath
                 << "fileSize:" << fileSize << "totalBytes:" << info.totalBytes
                 << "downloadedBytes:" << info.downloadedBytes;
        m_completedTable->setItem(i, 3, new QTableWidgetItem(formatFileSize(fileSize)));
        m_completedTable->setItem(i, 4, new QTableWidgetItem(info.finishTime.toString("yyyy-MM-dd HH:mm")));
    }

    // 不调用 resizeColumnsToContents()，保留UI设计师设置的列宽
    m_completedTable->viewport()->update();
    m_completedTable->update();

    qDebug() << "refreshCompletedTable: 完成，行数:" << m_completedTable->rowCount();
}

QString DownloadPage::formatFileSize(qint64 bytes)
{
    if (bytes < 1024) return QString::number(bytes) + " B";
    if (bytes < 1024*1024) return QString::number(bytes/1024.0,'f',2) + " KB";
    if (bytes < 1024*1024*1024) return QString::number(bytes/(1024.0*1024.0),'f',2) + " MB";
    return QString::number(bytes/(1024.0*1024.0*1024.0),'f',2) + " GB";
}

void DownloadPage::onTaskAdded(const QString &taskId)
{
    qDebug() << "onTaskAdded:" << taskId;
    Q_UNUSED(taskId);
    refreshDownloadingTable();
    refreshCompletedTable();  // 【修复】同时刷新已完成表格，确保持久化加载的任务能显示
}
void DownloadPage::onProgressUpdated(const QString &taskId, qint64 downloaded, qint64 total)
{ Q_UNUSED(taskId); Q_UNUSED(downloaded); Q_UNUSED(total); refreshDownloadingTable(); }
void DownloadPage::onStatusChanged(const QString &taskId, DownloadStatus status)
{
    qDebug() << "onStatusChanged:" << taskId << "状态:" << status;
    Q_UNUSED(taskId);
    refreshDownloadingTable();
    if (status == DownloadCompleted || status == DownloadFailed) {
        refreshCompletedTable();
        QTimer::singleShot(100, this, [this]() { refreshCompletedTable(); });
    }
}
void DownloadPage::onTaskCompleted(const DownloadInfo &info)
{
    qDebug() << "onTaskCompleted:" << info.songName;
    Q_UNUSED(info);
    refreshDownloadingTable();
    refreshCompletedTable();
    // 下载完成后，如果本地文件存在，自动播放
    QFileInfo fi(info.savePath);
    if (fi.exists()) {
        qDebug() << "下载完成，自动播放:" << info.songName << fi.absoluteFilePath();
        emit sig_playMusic(fi.absoluteFilePath(), info.songName, 0, info.songId);
    }
}

void DownloadPage::onSyncDownloadsFinished(bool success, const QString &message)
{
    qDebug() << "下载记录同步结果:" << success << message;
    refreshDownloadingTable();
    refreshCompletedTable();
}

void DownloadPage::onDownloadingDoubleClicked(int row, int column)
{ Q_UNUSED(row); Q_UNUSED(column); }

void DownloadPage::onCompletedDoubleClicked(int row, int column)
{
    Q_UNUSED(column);
    if (m_completedTable.isNull() || m_downloadManager.isNull()) return;
    QTableWidgetItem *item = m_completedTable->item(row, 0);
    if (!item) return;
    QString taskId = item->data(Qt::UserRole).toString();
    qDebug() << "双击完成项，taskId:" << taskId;
    DownloadInfo info = m_downloadManager->getTaskInfo(taskId);
    qDebug() << "歌曲:" << info.songName << "savePath:" << info.savePath;

    // 检查本地文件是否存在
    QFileInfo fi(info.savePath);
    if (!fi.exists()) {
        qDebug() << "本地文件不存在，尝试重新下载:" << info.songName;
        // 重新发起下载，下载完成后会自动播放
        // 先检查是否已在下载
        QList<DownloadInfo> tasks = m_downloadManager->getAllTasks();
        bool alreadyDownloading = false;
        for (const DownloadInfo &t : tasks) {
            if (t.songId == info.songId && t.type == info.type) {
                alreadyDownloading = true;
                break;
            }
        }
        if (!alreadyDownloading) {
            // 重新设置正确的 savePath（防止旧数据路径不对）
            QString safeArtist   = info.artist;
            QString safeSongName = info.songName;
            safeArtist.replace(QRegularExpression("[/:*?\"<>|]"), "_");
            safeSongName.replace(QRegularExpression("[/:*?\"<>|]"), "_");
            QString musicDir = QCoreApplication::applicationDirPath() + "/music";
            QDir dir(musicDir);
            if (!dir.exists()) dir.mkpath(".");
            info.savePath = QString("%1/%2 - %3.mp3").arg(musicDir).arg(safeArtist).arg(safeSongName);

            m_downloadManager->addDownloadTask(info);
            qDebug() << "已重新加入下载队列:" << info.songName;
        }
        return;
    }

    qDebug() << "本地文件存在，直接播放:" << fi.absoluteFilePath();
    emit sig_playMusic(fi.absoluteFilePath(), info.songName, 0, info.songId);
}
void DownloadPage::onPauseButtonClicked()
{
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn || !m_downloadManager) return;
    QString taskId = btn->property("taskId").toString();
    DownloadInfo info = m_downloadManager->getTaskInfo(taskId);
    if (info.status == DownloadDownloading) {
        m_downloadManager->pauseTask(taskId);
        btn->setText(QStringLiteral("继续"));
    } else if (info.status == DownloadPaused) {
        m_downloadManager->resumeTask(taskId);
        btn->setText(QStringLiteral("暂停"));
    }
}
void DownloadPage::onDeleteButtonClicked()
{
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn || !m_downloadManager) return;
    QString taskId = btn->property("taskId").toString();
    m_downloadManager->cancelTask(taskId);
    refreshDownloadingTable();
}
void DownloadPage::onClearButtonClicked()
{
    if (m_downloadManager) { m_downloadManager->clearCompletedTasks(); refreshCompletedTable(); }
}
