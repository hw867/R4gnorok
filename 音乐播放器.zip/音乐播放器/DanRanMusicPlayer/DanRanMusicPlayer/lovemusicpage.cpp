#include "loveMusicPage.h"
#include "config.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QHeaderView>
#include <QTabWidget>
#include <QHBoxLayout>
#include <QPushButton>
#include <QDebug>
#include <QRegularExpression>
#include "downloadtask.h"
#include "downloadmanager.h"
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QCoreApplication>
#include <QDir>

// 从 config.h 读取配置，无需在此处硬编码 IP
const QString LoveMusicPage::SERVER_HOST = SERVER_HOST_STRING;
const QString MUSIC_API_BASE_URL = MUSIC_API_BASE_URL_STRING;

LoveMusicPage::LoveMusicPage(QWidget *container, QObject *parent)
    : QObject(parent)
    , m_syncInProgress(false)
    , m_downloadManager(nullptr)
    , m_networkManager(nullptr)
{
    // 找到 UI 中的表格控件
    QTabWidget *tabWidget = container->findChild<QTabWidget*>("tabWidget");
    if (!tabWidget) {
        qWarning() << "LoveMusicPage: 未找到 tabWidget";
        return;
    }
    QWidget *songTab = tabWidget->widget(0); // 第一个标签页"歌曲"
    if (!songTab) return;

    m_tableWidget = songTab->findChild<QTableWidget*>("table_loveMusic");
    if (!m_tableWidget) {
        qWarning() << "LoveMusicPage: 未找到 table_loveMusic";
        return;
    }

    // 初始化网络管理器
    m_networkManager = new QNetworkAccessManager(this);

    connect(m_tableWidget, &QTableWidget::cellDoubleClicked,
            this, &LoveMusicPage::onTableDoubleClicked);

    // 不再从本地文件加载，登录后会从服务器同步
    refreshTable();
}

LoveMusicPage::~LoveMusicPage()
{
    // 不再保存本地文件
}

QJsonObject LoveMusicPage::favoriteItemToJson(const FavoriteItem &item)
{
    QJsonObject obj;
    obj["id"]       = item.id;
    obj["name"]     = item.name;
    obj["artist"]   = item.artist;
    obj["album"]    = item.album;
    obj["duration"] = item.duration;
    obj["type"]     = item.type;
    obj["picUrl"]   = item.picUrl;
    return obj;
}

FavoriteItem LoveMusicPage::jsonToFavoriteItem(const QJsonObject &obj)
{
    FavoriteItem item;
    item.id       = obj["id"].toString();
    item.name     = obj["name"].toString();
    item.artist   = obj["artist"].toString();
    item.album    = obj["album"].toString();
    item.duration = obj["duration"].toString();
    item.type     = obj["type"].toInt();
    item.picUrl   = obj["picUrl"].toString();
    return item;
}

void LoveMusicPage::refreshTable()
{
    m_tableWidget->clearContents();
    m_tableWidget->setRowCount(0);

    for (int i = 0; i < m_favoriteSongs.size(); ++i) {
        const FavoriteItem &fav = m_favoriteSongs[i];
        m_tableWidget->insertRow(i);
        m_tableWidget->setItem(i, 0, new QTableWidgetItem(fav.name));
        m_tableWidget->setItem(i, 1, new QTableWidgetItem(fav.artist));
        m_tableWidget->setItem(i, 2, new QTableWidgetItem(fav.album));
        m_tableWidget->setItem(i, 3, new QTableWidgetItem(fav.duration));

        // 操作按钮列（红心 + 下载按钮，同一列）
        QWidget *widget = new QWidget();
        QHBoxLayout *layout = new QHBoxLayout(widget);
        layout->setContentsMargins(5, 0, 5, 0);
        layout->setSpacing(5);

        // 红心按钮（移除喜欢）
        QPushButton *btnRemove = new QPushButton;
        btnRemove->setIcon(QIcon(":/Messageform/images/Messageform/like.png"));
        btnRemove->setToolTip("取消喜欢");
        btnRemove->setFlat(true);
        btnRemove->setFixedSize(30, 30);
        btnRemove->setProperty("songId", fav.id);
        btnRemove->setProperty("songType", fav.type);
        connect(btnRemove, &QPushButton::clicked, this, &LoveMusicPage::onRemoveButtonClicked);
        layout->addWidget(btnRemove);

        // 下载按钮（仅在线歌曲显示）
        if (fav.type == 1) {
            QPushButton *btnDownload = new QPushButton;
            btnDownload->setIcon(QIcon(":/listWidget/images/listWidget/btn_download.png"));
            btnDownload->setToolTip("下载歌曲");
            btnDownload->setFlat(true);
            btnDownload->setFixedSize(30, 30);
            btnDownload->setProperty("songId", fav.id);
            btnDownload->setProperty("songType", fav.type);
            btnDownload->setProperty("songName", fav.name);
            btnDownload->setProperty("artist", fav.artist);
            btnDownload->setProperty("album", fav.album);
            btnDownload->setProperty("duration", fav.duration);
            btnDownload->setProperty("picUrl", fav.picUrl);
            connect(btnDownload, &QPushButton::clicked, this, &LoveMusicPage::onDownloadButtonClicked);
            layout->addWidget(btnDownload);
        }

        layout->addStretch();
        m_tableWidget->setCellWidget(i, 4, widget);
    }
}

void LoveMusicPage::onRemoveButtonClicked()
{
    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn) return;
    QString id = btn->property("songId").toString();
    int type = btn->property("songType").toInt();
    removeFavorite(id, type);
}

void LoveMusicPage::onDownloadButtonClicked()
{
    qDebug() << "onDownloadButtonClicked 被调用";
    qDebug() << "m_downloadManager 指针:" << m_downloadManager;

    if (!m_downloadManager) {
        qWarning() << "下载管理器未初始化";
        return;
    }

    QPushButton *btn = qobject_cast<QPushButton*>(sender());
    if (!btn) {
        qWarning() << "无法获取信号发送者";
        return;
    }
    qDebug() << "下载按钮被点击，歌曲ID:" << btn->property("songId").toString();

    QString songId   = btn->property("songId").toString();
    int type          = btn->property("songType").toInt();
    QString songName  = btn->property("songName").toString();
    QString artist    = btn->property("artist").toString();
    QString album     = btn->property("album").toString();
    QString duration  = btn->property("duration").toString();
    QString picUrl    = btn->property("picUrl").toString();

    // 检查是否已经在下载
    for (DownloadInfo info : m_downloadManager->getAllTasks()) {
        if (info.songId == songId && info.type == type) {
            qDebug() << "歌曲已在下载列表中:" << songName;
            return;
        }
    }

    // 构建保存路径（保存到程序所在目录的 music 子目录）
    QString safeArtist   = artist;
    QString safeSongName = songName;
    safeArtist.replace(QRegularExpression("[/:*?\"<>|]"), "_");
    safeSongName.replace(QRegularExpression("[/:*?\"<>|]"), "_");

    QString musicDir = QCoreApplication::applicationDirPath() + "/music";
    QDir dir(musicDir);
    if (!dir.exists()) dir.mkpath(".");

    QString savePath = QString("%1/%2 - %3.mp3").arg(musicDir).arg(safeArtist).arg(safeSongName);
    QString lyricPath = QCoreApplication::applicationDirPath() + "/lrc/" + safeArtist + " - " + safeSongName + ".lrc";

    // 向音乐API代理请求下载URL（Node.js 3000端口）
    QString url = QString("%1/song/url?id=%2").arg(MUSIC_API_BASE_URL).arg(songId);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    DownloadInfo info;
    info.songId   = songId;
    info.songName  = songName;
    info.artist    = artist;
    info.album     = album;
    info.duration  = duration;
    info.type      = type;
    info.picUrl    = picUrl;
    info.savePath  = savePath;
    info.lyricPath = lyricPath;
    info.status    = DownloadWaiting;

    QNetworkReply *reply = m_networkManager->get(request);
    reply->setProperty("downloadInfo", QVariant::fromValue(info));
    connect(reply, &QNetworkReply::finished, this, &LoveMusicPage::onGetDownloadUrlReplyFinished);

    qDebug() << "开始请求下载URL:" << songName;
}

void LoveMusicPage::onTableDoubleClicked(int row, int column)
{
    Q_UNUSED(column);
    if (row < 0 || row >= m_favoriteSongs.size()) return;
    const FavoriteItem &fav = m_favoriteSongs[row];
    QString source = (fav.type == 0) ? fav.id : "";
    emit sig_playMusic(source, fav.name, fav.type, fav.id);
}

void LoveMusicPage::addFavorite(const FavoriteItem &item)
{
    if (m_currentUserId.isEmpty()) {
        qDebug() << "未登录，不能添加喜欢";
        return;
    }
    if (isFavorite(item.id, item.type)) return;
    m_favoriteSongs.append(item);
    refreshTable();
    emit sig_favoriteChanged(item.id, item.type, true);

    // 同步到服务器
    QString url = QString("%1/api/favorites/add").arg(SERVER_HOST);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject json;
    json["user_id"] = m_currentUserId;
    json["id"]       = item.id;
    json["name"]     = item.name;
    json["artist"]   = item.artist;
    json["album"]    = item.album;
    json["duration"] = item.duration;
    json["type"]     = item.type;
    json["picUrl"]   = item.picUrl;

    QNetworkReply *reply = m_networkManager->post(request, QJsonDocument(json).toJson());
    connect(reply, &QNetworkReply::finished, this, &LoveMusicPage::onAddReplyFinished);
    qDebug() << "添加喜欢，已同步到服务器:" << item.name;
}

void LoveMusicPage::removeFavorite(const QString &id, int type)
{
    for (int i = 0; i < m_favoriteSongs.size(); ++i) {
        if (m_favoriteSongs[i].id == id && m_favoriteSongs[i].type == type) {
            m_favoriteSongs.removeAt(i);
            break;
        }
    }
    refreshTable();
    emit sig_favoriteChanged(id, type, false);

    // 同步到服务器
    if (!m_currentUserId.isEmpty()) {
        QString url = QString("%1/api/favorites?user_id=%2&id=%3&type=%4")
                              .arg(SERVER_HOST)
                              .arg(m_currentUserId)
                              .arg(id)
                              .arg(type);
        QNetworkRequest request;
        request.setUrl(QUrl(url));
        request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
        m_networkManager->deleteResource(request);
    }
}

bool LoveMusicPage::isFavorite(const QString &id, int type) const
{
    for (const FavoriteItem &item : m_favoriteSongs) {
        if (item.id == id && item.type == type) return true;
    }
    return false;
}

QList<FavoriteItem> LoveMusicPage::getAllFavorites() const
{
    return m_favoriteSongs;
}

bool LoveMusicPage::getFavoriteInfo(const QString &id, int type, FavoriteItem &outItem) const
{
    for (const FavoriteItem &item : m_favoriteSongs) {
        if (item.id == id && item.type == type) {
            outItem = item;
            return true;
        }
    }
    return false;
}

void LoveMusicPage::setDownloadManager(DownloadManager *manager)
{
    m_downloadManager = manager;
    qDebug() << "LoveMusicPage::setDownloadManager 被调用，m_downloadManager:" << m_downloadManager;
}

void LoveMusicPage::setCurrentUserId(const QString &userId)
{
    if (userId.isEmpty()) {
        m_currentUserId.clear();
        m_favoriteSongs.clear();
        refreshTable();
        return;
    }
    m_currentUserId = userId;
}

// ========== 云端同步实现 ==========

void LoveMusicPage::syncWithServer(const QString &userId)
{
    if (userId.isEmpty()) {
        qDebug() << "未提供用户ID，无法同步";
        return;
    }

    if (m_syncInProgress) {
        qDebug() << "同步进行中，跳过";
        return;
    }

    m_syncInProgress = true;
    emit sig_syncStarted();

    qDebug() << "登录成功，正在同步喜欢列表...";

    // 从服务器拉取完整列表
    QString url = QString("%1/api/favorites?user_id=%2").arg(SERVER_HOST).arg(userId);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QNetworkReply *reply = m_networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &LoveMusicPage::onGetListReplyFinished);
}

void LoveMusicPage::onGetListReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();
    m_syncInProgress = false;

    if (reply->error() != QNetworkReply::NoError) {
        QString errorMsg = QString("拉取喜欢列表失败: %1").arg(reply->errorString());
        qDebug() << errorMsg;
        emit sig_syncFinished(false, errorMsg);
        return;
    }

    QByteArray data = reply->readAll();
    qDebug() << "服务器返回的喜欢列表:" << data;

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        emit sig_syncFinished(false, "响应格式错误");
        return;
    }

    QJsonObject obj = doc.object();
    int code = obj["code"].toInt(-1);
    if (code != 0) {
        emit sig_syncFinished(false, obj["message"].toString());
        return;
    }

    // 清空本地，用服务器数据全覆盖
    m_favoriteSongs.clear();

    QJsonArray songsArray = obj["data"].toObject()["songs"].toArray();
    for (const QJsonValue &val : songsArray) {
        QJsonObject songObj = val.toObject();
        m_favoriteSongs.append(jsonToFavoriteItem(songObj));
    }

    refreshTable();

    QString msg = QString("喜欢列表同步完成！共 %1 首").arg(m_favoriteSongs.size());
    qDebug() << msg;
    emit sig_syncFinished(true, msg);
}

void LoveMusicPage::onAddReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();

    if (reply->error() != QNetworkReply::NoError) {
        qDebug() << "添加喜欢到服务器失败:" << reply->errorString();
        return;
    }

    qDebug() << "添加喜欢到服务器成功";
}

void LoveMusicPage::onGetDownloadUrlReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();

    DownloadInfo info = reply->property("downloadInfo").value<DownloadInfo>();

    if (reply->error() != QNetworkReply::NoError) {
        qDebug() << "获取下载URL失败:" << reply->errorString();
        return;
    }

    QByteArray data = reply->readAll();
    qDebug() << "获取下载URL返回:" << data;

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        qDebug() << "响应格式错误";
        return;
    }

    QJsonObject obj = doc.object();
    int code = obj["code"].toInt(-1);
    if (code != 200) {
        qDebug() << "获取下载URL失败，错误码:" << code;
        return;
    }

    QJsonArray dataArray = obj["data"].toArray();
    if (dataArray.isEmpty()) {
        qDebug() << "歌曲数据为空";
        return;
    }

    QJsonObject songData = dataArray.first().toObject();
    info.musicUrl = songData["url"].toString();
    info.lyricUrl = QString("%1/lyric?id=%2").arg(MUSIC_API_BASE_URL).arg(info.songId);

    if (info.musicUrl.isEmpty()) {
        qDebug() << "音乐下载URL为空";
        return;
    }

    qDebug() << "获取到下载URL:" << info.musicUrl;

    if (m_downloadManager) {
        m_downloadManager->addDownloadTask(info);
        qDebug() << "已添加到下载管理器:" << info.songName;
    }
}
