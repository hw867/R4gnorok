#ifndef DOWNLOADTASK_H
#define DOWNLOADTASK_H

#include <QObject>
#include <QMetaType>
#include <QDateTime>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QFile>
#include <QUrl>

// 下载任务状态
enum DownloadStatus {
    DownloadWaiting,     // 等待下载
    DownloadDownloading, // 下载中
    DownloadPaused,      // 暂停
    DownloadCompleted,    // 完成
    DownloadFailed       // 失败
};

// 下载任务信息
struct DownloadInfo {
    QString taskId;       // 任务ID
    QString songId;       // 歌曲ID
    QString songName;     // 歌曲名
    QString artist;       // 歌手
    QString album;        // 专辑
    QString duration;     // 时长
    int type;             // 0:本地, 1:在线
    QString picUrl;       // 封面URL
    QString musicUrl;     // 音乐下载URL
    QString lyricUrl;     // 歌词下载URL
    QString savePath;     // 保存路径
    QString lyricPath;    // 歌词保存路径
    qint64 downloadedBytes; // 已下载字节数
    qint64 totalBytes;      // 总字节数
    DownloadStatus status;   // 下载状态
    QDateTime addTime;      // 添加时间
    QDateTime finishTime;    // 完成时间
};

// 注册为元类型，以便在QVariant中使用
Q_DECLARE_METATYPE(DownloadInfo)
Q_DECLARE_METATYPE(DownloadStatus)  // 注册 DownloadStatus 为元类型，支持跨线程信号槽

class DownloadTask : public QObject
{
    Q_OBJECT
public:
    explicit DownloadTask(QObject *parent = nullptr);
    ~DownloadTask();

    // 设置下载信息
    void setDownloadInfo(const DownloadInfo &info);
    DownloadInfo getDownloadInfo() const;

    // 【新增】仅更新状态（用于持久化加载后修正状态）
    void setStatus(DownloadStatus status);

    // 开始下载
    void startDownload();
    // 暂停下载
    void pauseDownload();
    // 恢复下载
    void resumeDownload();
    // 取消下载
    void cancelDownload();

signals:
    // 下载进度更新
    void sig_progressUpdated(const QString &taskId, qint64 downloaded, qint64 total);
    // 下载状态变化
    void sig_statusChanged(const QString &taskId, DownloadStatus status);
    // 下载完成
    void sig_downloadFinished(const QString &taskId, bool success, const QString &errorMsg);
    // 下载完成（包括歌曲信息，用于添加到本地音乐）
    void sig_downloadCompleted(const DownloadInfo &info);

private slots:
    void onMusicDownloadFinished();
    void onMusicDownloadProgress(qint64 bytesReceived, qint64 bytesTotal);
    void onLyricDownloadFinished();
    void onPicDownloadFinished();  // 封面下载完成

private:
    void downloadMusic();
    void downloadLyric();
    void downloadLyricWithCallback();  // 新增：使用回调方式的歌词下载
    void downloadCover();              // 新增：下载封面图片

    QNetworkAccessManager *m_networkManager;
    QNetworkReply *m_musicReply;
    QNetworkReply *m_picReply;   // 封面下载reply
    QFile *m_musicFile;
    DownloadInfo m_info;
    bool m_isCancelled;
    QString m_coverSavePath;      // 封面保存路径
};

#endif // DOWNLOADTASK_H
