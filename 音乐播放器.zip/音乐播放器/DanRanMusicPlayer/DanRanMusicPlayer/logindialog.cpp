#include "logindialog.h"
#include "loginmanager.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QImage>
#include <QMessageBox>

LoginDialog::LoginDialog(QWidget *parent)
    : QDialog(parent)
{
    setWindowTitle("扫码登录");
    setFixedSize(320, 450);
    QVBoxLayout *layout = new QVBoxLayout(this);

    m_qrLabel = new QLabel(this);
    m_qrLabel->setAlignment(Qt::AlignCenter);
    m_qrLabel->setFixedSize(250, 250);
    layout->addWidget(m_qrLabel);

    QLabel *tip = new QLabel("请使用手机扫描二维码登录", this);
    tip->setAlignment(Qt::AlignCenter);
    layout->addWidget(tip);

    QLabel *mockTip = new QLabel("（模拟阶段：请点击下方按钮完成登录）", this);
    mockTip->setAlignment(Qt::AlignCenter);
    mockTip->setStyleSheet("color: gray; font-size: 10px;");
    layout->addWidget(mockTip);

    m_simulateBtn = new QPushButton("模拟扫码登录", this);
    layout->addWidget(m_simulateBtn);

    m_cancelBtn = new QPushButton("取消", this);
    layout->addWidget(m_cancelBtn);

    connect(m_cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
    connect(m_simulateBtn, &QPushButton::clicked, this, &LoginDialog::onSimulateLoginClicked);
    connect(LoginManager::instance(), &LoginManager::qrCodeReady, this, [this](const QImage &img){
        m_qrLabel->setPixmap(QPixmap::fromImage(img).scaled(250,250, Qt::KeepAspectRatio));
    });
    connect(LoginManager::instance(), &LoginManager::loginSuccess, this, [this](const User &user){
        Q_UNUSED(user);
        accept();
        emit loginSuccess();
    });
    connect(LoginManager::instance(), &LoginManager::loginFailed, this, [](const QString &reason){
        QMessageBox::warning(nullptr, "登录失败", reason);
    });

    // 请求生成二维码
    LoginManager::instance()->requestLoginToken();
}

LoginDialog::~LoginDialog() {}

void LoginDialog::onSimulateLoginClicked()
{
    LoginManager::instance()->manualLogin();
}
