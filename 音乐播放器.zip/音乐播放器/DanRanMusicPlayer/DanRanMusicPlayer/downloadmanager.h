#ifndef DOWNLOADMANAGER_H
#define DOWNLOADMANAGER_H

#include <QObject>
#include <QMap>
#include <QList>
#include "downloadtask.h"

// 前置声明
class QNetworkAccessManager;
class QNetworkReply;

class DownloadManager : public QObject
{
    Q_OBJECT
public:
    explicit DownloadManager(QObject *parent = nullptr);
    ~DownloadManager();

    // 添加下载任务
    QString addDownloadTask(const DownloadInfo &info);
    // 暂停任务
    void pauseTask(const QString &taskId);
    // 恢复任务
    void resumeTask(const QString &taskId);
    // 取消任务
    void cancelTask(const QString &taskId);
    // 获取所有任务
    QList<DownloadInfo> getAllTasks() const;
    // 获取正在下载的任务
    QList<DownloadInfo> getDownloadingTasks() const;
    // 获取已完成的任务
    QList<DownloadInfo> getCompletedTasks() const;
    // 获取任务信息
    DownloadInfo getTaskInfo(const QString &taskId) const;
    // 清除已完成的任务
    void clearCompletedTasks();

    // ========== 服务器端同步接口 ==========
    // 设置当前登录用户ID
    void setCurrentUserId(const QString &userId);
    // 从服务器同步下载记录到本地
    void syncDownloadsWithServer();

signals:
    // 任务添加
    void sig_taskAdded(const QString &taskId);
    // 进度更新
    void sig_progressUpdated(const QString &taskId, qint64 downloaded, qint64 total);
    // 状态变化
    void sig_statusChanged(const QString &taskId, DownloadStatus status);
    // 任务完成
    void sig_taskCompleted(const DownloadInfo &info);
    // 同步完成
    void sig_syncDownloadsFinished(bool success, const QString &msg);

private slots:
    // 任务完成后的处理
    void onTaskFinished(const QString &taskId, bool success, const QString &errorMsg);
    // 同步下载记录回复
    void onSyncDownloadsReplyFinished();
    // 上传下载记录回复
    void onUploadDownloadReplyFinished();

private:
    // 上传单条下载记录到服务器
    void uploadDownloadRecord(const DownloadInfo &info);

    static const QString SERVER_HOST;

    QMap<QString, DownloadTask*> m_tasks;
    QNetworkAccessManager *m_networkManager;
    QString m_currentUserId;
};

#endif // DOWNLOADMANAGER_H
