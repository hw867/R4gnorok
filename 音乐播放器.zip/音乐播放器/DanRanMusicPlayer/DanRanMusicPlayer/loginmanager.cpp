#include "loginmanager.h"
#include "config.h"
#include <QRandomGenerator>
#include <QDebug>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMessageBox>
#include "qrcodegen.hpp"

// 从 config.h 读取配置，无需在此处硬编码 IP
const QString LoginManager::SERVER_HOST = SERVER_HOST_STRING;

LoginManager* LoginManager::m_instance = nullptr;

LoginManager* LoginManager::instance()
{
    if (!m_instance)
        m_instance = new LoginManager();
    return m_instance;
}

LoginManager::LoginManager(QObject *parent)
    : QObject(parent)
    , m_waitingForRegister(false)
{
    m_networkManager = new QNetworkAccessManager(this);
    m_checkTimer = new QTimer(this);
    connect(m_checkTimer, &QTimer::timeout, this, &LoginManager::onCheckTimeout);
}

LoginManager::~LoginManager()
{
    m_checkTimer->stop();
}

void LoginManager::requestLoginToken()
{
    qDebug() << "正在请求登录token...";

    QString url = QString("%1/api/login/token").arg(SERVER_HOST);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    // 发送请求
    QNetworkReply *reply = m_networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &LoginManager::onTokenReplyFinished);
}

void LoginManager::onTokenReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();

    if (reply->error() != QNetworkReply::NoError) {
        QString errorMsg = QString("网络错误: %1").arg(reply->errorString());
        qDebug() << errorMsg;
        emit loginFailed(errorMsg);
        return;
    }

    QByteArray data = reply->readAll();
    qDebug() << "服务器响应:" << data;

    // 解析JSON
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        emit loginFailed("响应格式错误");
        return;
    }

    QJsonObject obj = doc.object();
    int code = obj["code"].toInt(-1);
    QString message = obj["message"].toString();

    if (code != 0) {
        emit loginFailed(message);
        return;
    }

    // 提取token和qr_url
    QJsonObject dataObj = obj["data"].toObject();
    m_currentToken = dataObj["token"].toString();
    m_qrUrl = dataObj["qr_url"].toString();

    if (m_currentToken.isEmpty()) {
        emit loginFailed("未获取到token");
        return;
    }

    qDebug() << "获取token成功:" << m_currentToken;
    qDebug() << "二维码URL:" << m_qrUrl;

    // 生成二维码
    QImage qrImage = generateQRCode(m_qrUrl);
    if (!qrImage.isNull()) {
        emit qrCodeReady(qrImage);
    }

    // 启动轮询定时器（每2秒检查一次）
    m_checkTimer->start(2000);
}

void LoginManager::onCheckTimeout()
{
    if (m_currentToken.isEmpty()) {
        m_checkTimer->stop();
        return;
    }

    QString url = QString("%1/api/login/check?token=%2").arg(SERVER_HOST).arg(m_currentToken);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QNetworkReply *reply = m_networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &LoginManager::onCheckReplyFinished);
}

void LoginManager::onCheckReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();

    if (reply->error() != QNetworkReply::NoError) {
        qDebug() << "检查登录状态失败:" << reply->errorString();
        return;
    }

    QByteArray data = reply->readAll();

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) return;

    QJsonObject obj = doc.object();
    int code = obj["code"].toInt(-1);

    if (code != 0) {
        qDebug() << "检查登录状态:" << obj["message"].toString();
        return;
    }

    // 获取status
    QJsonObject dataObj = obj["data"].toObject();
    int status = dataObj["status"].toInt(0);

    if (status == 1) {
        // 登录成功！
        m_checkTimer->stop();

        // 提取用户信息
        QJsonObject userObj = dataObj["user"].toObject();
        m_currentUser.userId = userObj["user_id"].toString();
        m_currentUser.userName = userObj["username"].toString();
        m_currentUser.avatarUrl = userObj["avatar_url"].toString();  // 保存服务器URL
        m_currentUser.avatarPath = "";  // 本地路径稍后由MainWindow下载后填充

        qDebug() << "登录成功! 用户:" << m_currentUser.userName << "头像URL:" << m_currentUser.avatarUrl;

        emit loginSuccess(m_currentUser);
    }
    // status == 0 表示还在等待扫码，什么都不做
}

void LoginManager::registerUser(const QString &username, const QString &password)
{
    if (username.isEmpty() || password.isEmpty()) {
        emit registerFailed("用户名和密码不能为空");
        return;
    }

    if (password.length() < 6) {
        emit registerFailed("密码长度至少6位");
        return;
    }

    qDebug() << "正在注册用户:" << username;

    QString url = QString("%1/api/user/register").arg(SERVER_HOST);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject json;
    json["username"] = username;
    json["password"] = password;

    QNetworkReply *reply = m_networkManager->post(request, QJsonDocument(json).toJson());
    m_waitingForRegister = true;

    connect(reply, &QNetworkReply::finished, this, &LoginManager::onRegisterReplyFinished);
}

void LoginManager::onRegisterReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();
    m_waitingForRegister = false;

    if (reply->error() != QNetworkReply::NoError) {
        emit registerFailed(QString("网络错误: %1").arg(reply->errorString()));
        return;
    }

    QByteArray data = reply->readAll();
    qDebug() << "注册响应:" << data;

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        emit registerFailed("响应格式错误");
        return;
    }

    QJsonObject obj = doc.object();
    int code = obj["code"].toInt(-1);
    QString message = obj["message"].toString();

    if (code == 0) {
        QString regUsername = obj["data"].toObject()["username"].toString();
        qDebug() << "注册成功:" << regUsername;
        emit registerSuccess(regUsername);
    } else {
        emit registerFailed(message);
    }
}

void LoginManager::manualLogin()
{
    // 模拟扫码登录成功（用于测试）
    m_checkTimer->stop();
    m_currentUser.userId = "manual_test_user";
    m_currentUser.userName = "测试用户";
    m_currentUser.avatarPath = "";
    qDebug() << "模拟登录成功! 用户:" << m_currentUser.userName;
    emit loginSuccess(m_currentUser);
}

QImage LoginManager::generateQRCode(const QString &data)
{
    using namespace qrcodegen;

    QrCode qr = QrCode::encodeText(data.toUtf8().constData(), QrCode::Ecc::MEDIUM);
    int size = qr.getSize();
    QImage qrImage(size * 4, size * 4, QImage::Format_RGB32);
    qrImage.fill(Qt::white);

    for (int y = 0; y < size; ++y) {
        for (int x = 0; x < size; ++x) {
            if (qr.getModule(x, y)) {
                for (int py = 0; py < 4; ++py) {
                    for (int px = 0; px < 4; ++px) {
                        qrImage.setPixel(x * 4 + px, y * 4 + py, qRgb(0, 0, 0));
                    }
                }
            }
        }
    }

    return qrImage;
}

bool LoginManager::parseJson(const QByteArray &data, int &code, QString &message)
{
    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) return false;

    QJsonObject obj = doc.object();
    code = obj["code"].toInt(-1);
    message = obj["message"].toString();
    return true;
}
