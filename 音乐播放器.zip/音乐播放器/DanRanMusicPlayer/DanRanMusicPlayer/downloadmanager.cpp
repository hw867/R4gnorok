#include "downloadmanager.h"
#include "config.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QDebug>
#include <QFileInfo>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QDateTime>
#include <QCoreApplication>
#include <QDir>

// 从 config.h 读取配置，无需在此处硬编码 IP
const QString DownloadManager::SERVER_HOST = SERVER_HOST_STRING;

DownloadManager::DownloadManager(QObject *parent)
    : QObject(parent)
    , m_networkManager(nullptr)
{
    m_networkManager = new QNetworkAccessManager(this);
}

DownloadManager::~DownloadManager()
{
    // 【修复】只取消正在下载的任务，不删除已完成的文件
    QList<QString> taskIds = m_tasks.keys();
    for (const QString &taskId : taskIds) {
        DownloadTask *task = m_tasks.value(taskId);
        if (task) {
            DownloadInfo info = task->getDownloadInfo();
            // 只取消未完成的状态，已完成的不删除文件
            if (info.status == DownloadWaiting ||
                info.status == DownloadDownloading ||
                info.status == DownloadPaused) {
                cancelTask(taskId);
            } else {
                // 已完成或失败，只删除任务对象，不删除文件
                task->deleteLater();
            }
        }
    }
    m_tasks.clear();
}

QString DownloadManager::addDownloadTask(const DownloadInfo &info)
{
    // 检查是否已存在相同歌曲的正在进行的下载任务
    for (DownloadTask *task : m_tasks) {
        DownloadInfo taskInfo = task->getDownloadInfo();
        if (taskInfo.songId == info.songId && taskInfo.type == info.type) {
            if (taskInfo.status == DownloadWaiting ||
                taskInfo.status == DownloadDownloading ||
                taskInfo.status == DownloadPaused) {
                qDebug() << "任务已存在（进行中），跳过:" << taskInfo.songName;
                return taskInfo.taskId;
            }
            qDebug() << "任务已存在（已完成/失败），保留旧任务并创建新下载:" << taskInfo.songName;
        }
    }

    // 创建新任务
    DownloadTask *task = new DownloadTask(this);
    task->setDownloadInfo(info);

    connect(task, &DownloadTask::sig_progressUpdated,
            this, &DownloadManager::sig_progressUpdated);
    connect(task, &DownloadTask::sig_statusChanged,
            this, &DownloadManager::sig_statusChanged);
    connect(task, &DownloadTask::sig_downloadFinished,
            this, &DownloadManager::onTaskFinished);
    connect(task, &DownloadTask::sig_downloadCompleted,
            this, &DownloadManager::sig_taskCompleted);

    QString actualTaskId = task->getDownloadInfo().taskId;
    m_tasks.insert(actualTaskId, task);
    qDebug() << "下载任务已创建，任务ID:" << actualTaskId << "歌曲:" << info.songName;

    task->startDownload();

    emit sig_taskAdded(actualTaskId);
    qDebug() << "已发出 sig_taskAdded 信号:" << actualTaskId;

    return actualTaskId;
}

void DownloadManager::pauseTask(const QString &taskId)
{
    if (m_tasks.contains(taskId)) {
        m_tasks[taskId]->pauseDownload();
    }
}

void DownloadManager::resumeTask(const QString &taskId)
{
    if (m_tasks.contains(taskId)) {
        m_tasks[taskId]->resumeDownload();
    }
}

void DownloadManager::cancelTask(const QString &taskId)
{
    if (m_tasks.contains(taskId)) {
        DownloadTask *task = m_tasks.take(taskId);
        DownloadInfo info = task->getDownloadInfo();
        // 如果是已完成状态，不删除文件
        if (info.status == DownloadCompleted) {
            task->deleteLater();
        } else {
            task->cancelDownload();
            task->deleteLater();
        }
    }
}

QList<DownloadInfo> DownloadManager::getAllTasks() const
{
    QList<DownloadInfo> list;
    for (DownloadTask *task : m_tasks) {
        list.append(task->getDownloadInfo());
    }
    return list;
}

QList<DownloadInfo> DownloadManager::getDownloadingTasks() const
{
    QList<DownloadInfo> list;
    for (DownloadTask *task : m_tasks) {
        DownloadInfo info = task->getDownloadInfo();
        if (info.status == DownloadWaiting || info.status == DownloadDownloading || info.status == DownloadPaused) {
            list.append(info);
        }
    }
    return list;
}

QList<DownloadInfo> DownloadManager::getCompletedTasks() const
{
    QList<DownloadInfo> list;
    for (DownloadTask *task : m_tasks) {
        DownloadInfo info = task->getDownloadInfo();
        if (info.status == DownloadCompleted || info.status == DownloadFailed) {
            list.append(info);
        }
    }
    return list;
}

DownloadInfo DownloadManager::getTaskInfo(const QString &taskId) const
{
    if (m_tasks.contains(taskId)) {
        return m_tasks[taskId]->getDownloadInfo();
    }
    return DownloadInfo();
}

void DownloadManager::clearCompletedTasks()
{
    QList<QString> toRemove;
    for (auto it = m_tasks.begin(); it != m_tasks.end(); ++it) {
        DownloadInfo info = it.value()->getDownloadInfo();
        if (info.status == DownloadCompleted || info.status == DownloadFailed) {
            toRemove.append(it.key());
        }
    }

    for (const QString &taskId : toRemove) {
        cancelTask(taskId);
    }
}

void DownloadManager::onTaskFinished(const QString &taskId, bool success, const QString &errorMsg)
{
    Q_UNUSED(errorMsg);

    if (success) {
        DownloadInfo info = getTaskInfo(taskId);
        if (info.status == DownloadCompleted) {
            // 下载成功完成，上传到服务器
            uploadDownloadRecord(info);
        }
    }
}

// ========== 服务器端同步实现 ==========

void DownloadManager::setCurrentUserId(const QString &userId)
{
    m_currentUserId = userId;
}

void DownloadManager::syncDownloadsWithServer()
{
    if (m_currentUserId.isEmpty()) {
        qDebug() << "未登录，无法同步下载记录";
        return;
    }

    QString url = QString("%1/api/downloads?user_id=%2").arg(SERVER_HOST).arg(m_currentUserId);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QNetworkReply *reply = m_networkManager->get(request);
    connect(reply, &QNetworkReply::finished, this, &DownloadManager::onSyncDownloadsReplyFinished);

    qDebug() << "正在从服务器同步下载记录...";
}

void DownloadManager::uploadDownloadRecord(const DownloadInfo &info)
{
    if (m_currentUserId.isEmpty()) {
        qDebug() << "未登录，不保存下载记录到服务器";
        return;
    }

    QString url = QString("%1/api/downloads/add").arg(SERVER_HOST);
    QNetworkRequest request;
    request.setUrl(QUrl(url));
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");

    QJsonObject json;
    json["user_id"]   = m_currentUserId;
    json["song_id"]    = info.songId;
    json["song_name"]  = info.songName;
    json["artist"]     = info.artist;
    json["album"]      = info.album;
    json["duration"]   = info.duration;
    json["type"]       = info.type;
    json["pic_url"]    = info.picUrl;
    json["save_path"]  = info.savePath;

    QFileInfo fileInfo(info.savePath);
    json["file_size"]  = fileInfo.exists() ? fileInfo.size() : 0;

    json["finish_time"] = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");

    QNetworkReply *reply = m_networkManager->post(request, QJsonDocument(json).toJson());
    connect(reply, &QNetworkReply::finished, this, &DownloadManager::onUploadDownloadReplyFinished);

    qDebug() << "上传下载记录到服务器:" << info.songName;
}

void DownloadManager::onSyncDownloadsReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();

    if (reply->error() != QNetworkReply::NoError) {
        QString errorMsg = QString("同步下载记录失败: %1").arg(reply->errorString());
        qDebug() << errorMsg;
        emit sig_syncDownloadsFinished(false, errorMsg);
        return;
    }

    QByteArray data = reply->readAll();
    qDebug() << "服务器返回的下载记录:" << data;

    QJsonDocument doc = QJsonDocument::fromJson(data);
    if (!doc.isObject()) {
        emit sig_syncDownloadsFinished(false, "响应格式错误");
        return;
    }

    QJsonObject obj = doc.object();
    int code = obj["code"].toInt(-1);
    if (code != 0) {
        emit sig_syncDownloadsFinished(false, obj["message"].toString());
        return;
    }

    // 解析下载记录列表
    QJsonArray downloadsArray = obj["data"].toObject()["downloads"].toArray();

    // 将服务器数据转换为 DownloadInfo 并添加到内存
    for (const QJsonValue &val : downloadsArray) {
        QJsonObject downloadObj = val.toObject();

        DownloadInfo info;
        info.songId   = downloadObj["song_id"].toString();
        info.songName = downloadObj["song_name"].toString();
        info.artist   = downloadObj["artist"].toString();
        info.album    = downloadObj["album"].toString();
        info.duration = downloadObj["duration"].toString();
        info.type     = downloadObj["type"].toInt();
        info.picUrl   = downloadObj["pic_url"].toString();
        info.totalBytes = downloadObj["file_size"].toVariant().toLongLong();
        info.finishTime = QDateTime::fromString(downloadObj["finish_time"].toString(), "yyyy-MM-dd HH:mm:ss");
        info.status   = DownloadCompleted;

        // 【关键修复】根据当前客户端环境重新构建 savePath
        // 服务端存的 save_path 可能是其他客户端的路径，需要重新构建
        QString serverSavePath = downloadObj["save_path"].toString();
        QFileInfo serverFileInfo(serverSavePath);
        QString fileName = serverFileInfo.fileName(); // 提取文件名，如 "郑润泽 - 于是.mp3"

        QString musicDir = QCoreApplication::applicationDirPath() + "/music";
        QDir dir(musicDir);
        if (!dir.exists()) dir.mkpath(".");
        info.savePath = musicDir + "/" + fileName;
        qDebug() << "同步下载记录，重新构建 savePath:" << serverSavePath << "->" << info.savePath;

        // 检查是否已存在
        bool exists = false;
        for (DownloadTask *task : m_tasks) {
            DownloadInfo taskInfo = task->getDownloadInfo();
            if (taskInfo.songId == info.songId && taskInfo.type == info.type) {
                exists = true;
                break;
            }
        }

        if (!exists) {
            DownloadTask *task = new DownloadTask(this);
            task->setDownloadInfo(info);
            // 【关键修复】用 task 内部的 taskId 作为 key，而不是 info.taskId（可能为空）
            QString actualTaskId = task->getDownloadInfo().taskId;
            m_tasks.insert(actualTaskId, task);
            qDebug() << "从服务器恢复下载记录:" << info.songName << "taskId:" << actualTaskId;
        }
    }

    QString msg = QString("下载记录同步完成！共 %1 条记录").arg(downloadsArray.size());
    qDebug() << msg;
    emit sig_syncDownloadsFinished(true, msg);
}

void DownloadManager::onUploadDownloadReplyFinished()
{
    QNetworkReply *reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;

    reply->deleteLater();

    if (reply->error() != QNetworkReply::NoError) {
        qDebug() << "上传下载记录失败:" << reply->errorString();
        return;
    }

    qDebug() << "上传下载记录成功";
}
