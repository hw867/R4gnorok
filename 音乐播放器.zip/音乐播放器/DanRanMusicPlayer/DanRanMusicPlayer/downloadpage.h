#ifndef DOWNLOADPAGE_H
#define DOWNLOADPAGE_H

#include <QObject>
#include <QWidget>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QPointer>
#include "downloadtask.h"
#include "downloadmanager.h"

class DownloadPage : public QObject
{
    Q_OBJECT
public:
    explicit DownloadPage(QWidget *container, QObject *parent = nullptr);
    ~DownloadPage();
    void setDownloadManager(DownloadManager *manager);

signals:
    void sig_playMusic(const QString &path, const QString &songName, int duration, const QString &songId);

private slots:
    void onTaskAdded(const QString &taskId);
    void onProgressUpdated(const QString &taskId, qint64 downloaded, qint64 total);
    void onStatusChanged(const QString &taskId, DownloadStatus status);
    void onTaskCompleted(const DownloadInfo &info);
    void onDownloadingDoubleClicked(int row, int column);
    void onCompletedDoubleClicked(int row, int column);
    void onPauseButtonClicked();
    void onDeleteButtonClicked();
    void onClearButtonClicked();
    void onSyncDownloadsFinished(bool success, const QString &message);

private:
    void refreshDownloadingTable();
    void refreshCompletedTable();
    void initTable(QTableWidget *table, const QStringList &headers);        // 新增
    void ensureTableStructure(QTableWidget *table, int expectedCols);         // 新增
    static QString formatFileSize(qint64 bytes);

    QWidget *m_container;
    QPointer<QTableWidget> m_downloadingTable;
    QPointer<QTableWidget> m_completedTable;
    QPointer<DownloadManager> m_downloadManager;
};

#endif // DOWNLOADPAGE_H
