#include "onlinemusicpage.h"
#include "config.h"
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMessageBox>
#include <QDebug>
#include <QTime>
#include <QPixmap>
#include <QBuffer>
#include <QImageReader>

// ========== 静态成员初始化 ==========
// 从 config.h 读取配置，无需在此处硬编码 IP
QString OnlineMusicPage::s_musicApiBaseUrl = MUSIC_API_BASE_URL_STRING;

// ========== 构造函数 ==========
OnlineMusicPage::OnlineMusicPage(QWidget *container, QObject *parent)
    : QObject(parent)
    , m_curPage(1)
    , m_pageSize(20)
    , m_totalPage(0)
    , m_totalCount(0)
    , m_currentPicSongName("")
{
    m_tableWidget    = container->findChild<QTableWidget*>("table_onlineMusicList");
    m_prevBtn        = container->findChild<QPushButton*>("pb_onlinePrevPage");
    m_nextBtn        = container->findChild<QPushButton*>("pb_onlineNextPage");
    m_pageInfoLabel  = container->findChild<QLabel*>("lb_onlinePageInfo");
    m_totalCountLabel = container->findChild<QLabel*>("lb_onlineTotalCount");

    if (!m_tableWidget || !m_prevBtn || !m_nextBtn) {
        qWarning() << "OnlineMusicPage: 找不到必需的UI控件";
        return;
    }

    connect(m_prevBtn, &QPushButton::clicked, this, &OnlineMusicPage::onPrevPageClicked);
    connect(m_nextBtn, &QPushButton::clicked, this, &OnlineMusicPage::onNextPageClicked);
    connect(m_tableWidget, &QTableWidget::cellDoubleClicked, this, &OnlineMusicPage::onTableDoubleClicked);

    m_searchRq   = new NetRequest(this);
    m_songUrlRq  = new NetRequest(this);
    m_lyricRq    = new NetRequest(this);
    m_picRq      = new NetRequest(this);

    connect(m_searchRq,  &NetRequest::SIG_getResult, this, &OnlineMusicPage::onSearchResult);
    connect(m_songUrlRq, &NetRequest::SIG_getResult, this, &OnlineMusicPage::onSongUrlResult);
    connect(m_lyricRq,   &NetRequest::SIG_getResult, this, &OnlineMusicPage::onLyricResult);
    connect(m_picRq,      &NetRequest::SIG_getResult, this, &OnlineMusicPage::onPicResult);
}

OnlineMusicPage::~OnlineMusicPage(){}

// ========== 静态方法 ==========
void OnlineMusicPage::setMusicApiBaseUrl(const QString &baseUrl)
{
    s_musicApiBaseUrl = baseUrl;
}

QString OnlineMusicPage::musicApiBaseUrl()
{
    return s_musicApiBaseUrl;
}

// ========== 搜索入口 ==========
void OnlineMusicPage::search(const QString &keyword)
{
    m_searchKey = keyword.trimmed();
    if (m_searchKey.isEmpty()) return;

    m_curPage = 1;
    emit sig_searchStatus(QString("正在搜索：%1 ...").arg(m_searchKey));

    int offset = (m_curPage - 1) * m_pageSize;
    QString url = QString("%1/cloudsearch?keywords=%2&offset=%3&limit=%4")
                     .arg(s_musicApiBaseUrl)
                     .arg(m_searchKey).arg(offset).arg(m_pageSize);

    qDebug() << "[搜索] URL：" << url;
    m_searchRq->slot_sendUrlRequest(url);
}

// ========== 分页 ==========
void OnlineMusicPage::onPrevPageClicked()
{
    if (m_curPage <= 1) return;
    m_curPage--;
    int offset = (m_curPage - 1) * m_pageSize;
    QString url = QString("%1/cloudsearch?keywords=%2&offset=%3&limit=%4")
                     .arg(s_musicApiBaseUrl)
                     .arg(m_searchKey).arg(offset).arg(m_pageSize);
    m_searchRq->slot_sendUrlRequest(url);
}

void OnlineMusicPage::onNextPageClicked()
{
    if (m_curPage >= m_totalPage) return;
    m_curPage++;
    int offset = (m_curPage - 1) * m_pageSize;
    QString url = QString("%1/cloudsearch?keywords=%2&offset=%3&limit=%4")
                     .arg(s_musicApiBaseUrl)
                     .arg(m_searchKey).arg(offset).arg(m_pageSize);
    m_searchRq->slot_sendUrlRequest(url);
}

// ========== 搜索结果处理 ==========
void OnlineMusicPage::onSearchResult(int code, QByteArray &bytes)
{
    if (code < 0) {
        QMessageBox::warning(nullptr, "提示", "搜索失败，请检查网络");
        emit sig_searchStatus("搜索失败");
        return;
    }

    QJsonParseError err;
    QJsonDocument json = QJsonDocument::fromJson(bytes, &err);
    if (err.error != QJsonParseError::NoError) {
        qDebug() << "[搜索] JSON解析失败：" << err.errorString();
        return;
    }

    QJsonObject resultObj = json.object().value("result").toObject();
    if (resultObj.isEmpty()) {
        emit sig_searchStatus("未找到相关歌曲");
        return;
    }

    m_totalCount = resultObj.value("songCount").toInt();
    m_totalPage = (m_totalCount + m_pageSize - 1) / m_pageSize;

    QJsonArray songs = resultObj.value("songs").toArray();
    QList<MusicInfoData> musicList;

    for (const QJsonValue &val : songs) {
        QJsonObject o = val.toObject();
        MusicInfoData info;
        info.songName   = o.value("name").toString();
        info.songID     = QString::number(o.value("id").toInt());
        info.singer     = o.value("ar").toArray().isEmpty() ? "未知歌手"
                        : o.value("ar").toArray().at(0).toObject().value("name").toString();
        info.albumName  = o.value("al").toObject().value("name").toString();
        info.songPicUrl = o.value("al").toObject().value("picUrl").toString();
        info.playTime   = QTime::fromMSecsSinceStartOfDay(o.value("dt").toInt()).toString("mm:ss");
        info.songSource = from_net;
        musicList.append(info);
    }

    showMusicList(musicList);
    m_pageInfoLabel->setText(QString("第 %1 / %2 页").arg(m_curPage).arg(m_totalPage));
    m_totalCountLabel->setText(QString("共 %1 首").arg(m_totalCount));
    emit sig_searchStatus(QString("搜索完成，找到 %1 首歌曲").arg(musicList.size()));
}

// ========== 显示音乐列表 ==========
void OnlineMusicPage::showMusicList(const QList<MusicInfoData> &musicList)
{
    m_tableWidget->clearContents();
    m_tableWidget->setRowCount(0);

    for (const MusicInfoData &info : musicList) {
        int row = m_tableWidget->rowCount();
        m_tableWidget->insertRow(row);

        MyTableWidgetItem *item0 = new MyTableWidgetItem;
        item0->setMusicInfoData(info);
        item0->setText(info.songName);

        MyTableWidgetItem *item1 = new MyTableWidgetItem;
        item1->setText(info.singer);

        MyTableWidgetItem *item2 = new MyTableWidgetItem;
        item2->setText(info.albumName);

        MyTableWidgetItem *item3 = new MyTableWidgetItem;
        item3->setText(info.playTime);

        m_tableWidget->setItem(row, 0, item0);
        m_tableWidget->setItem(row, 1, item1);
        m_tableWidget->setItem(row, 2, item2);
        m_tableWidget->setItem(row, 3, item3);
    }
}

// ========== 双击播放 ==========
void OnlineMusicPage::onTableDoubleClicked(int row, int column)
{
    Q_UNUSED(column);
    MyTableWidgetItem *item = dynamic_cast<MyTableWidgetItem*>(m_tableWidget->item(row, 0));
    if (!item) return;
    MusicInfoData info = item->musicInfoData();
    requestPlaySong(info);
}

// ========== 请求播放歌曲 ==========
void OnlineMusicPage::requestPlaySong(const MusicInfoData &info)
{
    m_currentRequestSongId = info.songID;
    m_currentRequestInfo   = info;

    QString url = QString("%1/song/url?id=%2").arg(s_musicApiBaseUrl).arg(info.songID);
    qDebug() << "[播放] 请求音源：" << url;
    m_songUrlRq->slot_sendUrlRequest(url);
}

// ========== 播放链接回调 ==========
void OnlineMusicPage::onSongUrlResult(int code, QByteArray &bytes)
{
    if (m_currentRequestSongId != m_currentRequestInfo.songID) {
        qDebug() << "忽略过期的播放URL回调";
        return;
    }
    if (code < 0) {
        QMessageBox::warning(nullptr, "提示", "获取播放链接失败");
        return;
    }

    QJsonParseError err;
    QJsonDocument json = QJsonDocument::fromJson(bytes, &err);
    if (err.error != QJsonParseError::NoError) return;
    if (!json.isObject()) return;

    QString playUrl;
    QJsonArray dataArr = json.object().value("data").toArray();
    if (!dataArr.isEmpty())
        playUrl = dataArr.at(0).toObject().value("url").toString();

    if (playUrl.isEmpty() || !playUrl.startsWith("http")) {
        QMessageBox::warning(nullptr, "提示",
            QString("歌曲《%1》暂无音源").arg(m_currentRequestInfo.songName));
        return;
    }

    // 请求歌词
    QString lyricUrl = QString("%1/lyric?id=%2").arg(s_musicApiBaseUrl).arg(m_currentRequestInfo.songID);
    m_lyricRq->slot_sendUrlRequest(lyricUrl);

    // 请求封面
    if (!m_currentRequestInfo.songPicUrl.isEmpty())
        m_picRq->slot_sendUrlRequest(m_currentRequestInfo.songPicUrl);

    emit sig_playOnlineSong(m_currentRequestInfo, playUrl);
}

// ========== 歌词处理 ==========
void OnlineMusicPage::onLyricResult(int code, QByteArray &bytes)
{
    if (m_currentRequestSongId != m_currentRequestInfo.songID) return;
    if (code < 0) return;

    QJsonParseError err;
    QJsonDocument json = QJsonDocument::fromJson(bytes, &err);
    if (err.error != QJsonParseError::NoError) return;
    if (!json.isObject()) return;

    QString lyricText = json.object().value("lrc").toObject().value("lyric").toString();
    if (!lyricText.isEmpty()) {
        saveLyricToFile(m_currentRequestInfo.songName, lyricText);
        emit sig_lyricsReady(m_currentRequestInfo.songName);
    }
}

// ========== 封面处理 ==========
void OnlineMusicPage::onPicResult(int code, QByteArray &bytes)
{
    if (code < 0) return;

    QString targetSongName;
    if (!m_currentRequestInfo.songID.isEmpty())
        targetSongName = m_currentRequestInfo.songName;
    else if (!m_currentPicSongName.isEmpty())
        targetSongName = m_currentPicSongName;
    else
        return;

    QPixmap pixmap;
    if (pixmap.loadFromData(bytes)) {
        saveCoverToFile(targetSongName, bytes);
        emit sig_coverReady(targetSongName, pixmap);
    }

    if (!m_currentPicSongName.isEmpty())
        m_currentPicSongName.clear();
}

void OnlineMusicPage::requestCoverByUrl(const QString &picUrl, const QString &songName)
{
    if (picUrl.isEmpty()) return;
    m_currentPicSongName = songName;
    m_picRq->slot_sendUrlRequest(picUrl);
}

// ========== 文件保存 ==========
void OnlineMusicPage::saveLyricToFile(const QString &songName, const QString &lyricText)
{
    QString lrcPath = QCoreApplication::applicationDirPath() + "/lrc/";
    QDir dir(lrcPath);
    if (!dir.exists()) dir.mkpath(lrcPath);
    QFile file(lrcPath + songName + ".lrc");
    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        file.write(lyricText.toUtf8());
        file.close();
    }
}

void OnlineMusicPage::saveCoverToFile(const QString &songName, const QByteArray &imageData)
{
    QBuffer buffer(const_cast<QByteArray*>(&imageData));
    if (!buffer.open(QIODevice::ReadOnly)) return;

    QByteArray format = QImageReader::imageFormat(&buffer);
    if (format.isEmpty()) format = "jpg";
    QString ext = (format == "jpeg") ? "jpg" : QString::fromUtf8(format).toLower();

    QString imgPath = QCoreApplication::applicationDirPath() + "/img/";
    QDir dir(imgPath);
    if (!dir.exists()) dir.mkpath(imgPath);
    QFile file(imgPath + songName + "." + ext);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(imageData);
        file.close();
    }
}
