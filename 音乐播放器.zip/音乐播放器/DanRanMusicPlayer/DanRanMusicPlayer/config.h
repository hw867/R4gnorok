#ifndef CONFIG_H
#define CONFIG_H

/**
 * 服务器配置集中管理
 * 换网络环境时，只需要修改这里的 IP 地址和端口号，全局生效
 */

// ================== 修改下面这两行即可 ==================
#define SERVER_IP_ADDRESS   "192.168.1.114"

#define SERVER_PORT         "8080"
#define MUSIC_API_PORT      "3000"
// ========================================================

// C 语言服务端（用户管理、收藏同步、下载记录同步）
#define SERVER_HOST_STRING "http://192.168.1.114:8080"

// Node.js 代理服务（网易云音乐 API 代理：搜索、获取下载地址、歌词等）
#define MUSIC_API_BASE_URL_STRING "http://192.168.1.114:3000"

#endif // CONFIG_H
