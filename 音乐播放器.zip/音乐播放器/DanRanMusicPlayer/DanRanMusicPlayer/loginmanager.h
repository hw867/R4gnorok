#ifndef LOGINMANAGER_H
#define LOGINMANAGER_H

#include <QObject>
#include <QString>
#include <QImage>
#include <QTimer>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QNetworkRequest>
#include "user.h"

class LoginManager : public QObject
{
    Q_OBJECT
public:
    static LoginManager* instance();

    // 请求登录token（生成二维码）
    void requestLoginToken();

    // 手动注册（如果需要）
    void registerUser(const QString &username, const QString &password);

    // 手动登录（模拟扫码成功，用于测试）
    void manualLogin();

    // 获取当前用户
    User currentUser() const { return m_currentUser; }

    // 获取当前token
    QString currentToken() const { return m_currentToken; }

    // 是否已登录
    bool isLoggedIn() const { return m_currentUser.isValid(); }

    // 获取服务器地址（公共方法）
    static QString getServerHost() { return SERVER_HOST; }

signals:
    void qrCodeReady(const QImage &qrImage);
    void loginSuccess(const User &user);
    void loginFailed(const QString &reason);
    void registerSuccess(const QString &username);
    void registerFailed(const QString &reason);

private slots:
    void onTokenReplyFinished();
    void onCheckReplyFinished();
    void onRegisterReplyFinished();
    void onCheckTimeout();

private:
    explicit LoginManager(QObject *parent = nullptr);
    ~LoginManager();

    // 生成二维码
    QImage generateQRCode(const QString &data);

    // 解析JSON响应
    bool parseJson(const QByteArray &data, int &code, QString &message);

    // 服务器配置（根据实际修改）
    static const QString SERVER_HOST;  // 例如: "http://192.168.1.100:8080"

    static LoginManager *m_instance;
    QString m_currentToken;
    QString m_qrUrl;
    User m_currentUser;

    QNetworkAccessManager *m_networkManager;
    QTimer *m_checkTimer;

    // 标记是否正在等待注册响应
    bool m_waitingForRegister;
};

#endif // LOGINMANAGER_H
