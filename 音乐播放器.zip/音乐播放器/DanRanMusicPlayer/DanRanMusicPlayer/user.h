#ifndef USER_H
#define USER_H

#include <QString>

struct User {
    QString userId;       // 唯一ID
    QString userName;     // 昵称
    QString avatarPath;   // 头像本地路径
    QString avatarUrl;    // 头像服务器URL
    bool isValid() const { return !userId.isEmpty(); }
    void clear() { userId.clear(); userName.clear(); avatarPath.clear(); avatarUrl.clear(); }
};

#endif // USER_H
