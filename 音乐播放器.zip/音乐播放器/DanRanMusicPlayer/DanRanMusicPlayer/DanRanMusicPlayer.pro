QT       += core gui widgets multimedia

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    downloadpage.cpp \
    downloadtask.cpp \
    downloadmanager.cpp \
    localmusicpage.cpp \
    logindialog.cpp \
    loginmanager.cpp \
    lovemusicpage.cpp \
    lyricspage.cpp \
    main.cpp \
    mainwindow.cpp \
    mytablewidgetitem.cpp \
    onlinemusicpage.cpp \
    qrcodegen.cpp

HEADERS += \
    config.h \
    downloadpage.h \
    downloadtask.h \
    downloadmanager.h \
    localmusicpage.h \
    logindialog.h \
    loginmanager.h \
    lovemusicpage.h \
    lyricspage.h \
    mainwindow.h \
    mytablewidgetitem.h \
    onlinemusicpage.h \
    qrcodegen.hpp \
    user.h

FORMS += \
    mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

include(./netRequest/netRequest.pri)
INCLUDEPATH += ./netRequest/

RESOURCES += \
    images.qrc

DISTFILES +=
